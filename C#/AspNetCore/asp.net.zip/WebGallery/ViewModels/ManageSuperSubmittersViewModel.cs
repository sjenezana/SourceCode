﻿using System.Collections.Generic;
using WebGallery.Models;

namespace WebGallery.ViewModels
{
    public class ManageSuperSubmittersViewModel
    {
        public IList<SubmittersContactDetail> SuperSubmitters { get; set; }
    }
}