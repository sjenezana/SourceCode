﻿using WebGallery.Models;

namespace WebGallery.ViewModels
{
    public class AccountDetailViewModel
    {
        public Submitter Submittership { get; set; }
        public SubmittersContactDetail ContactInfo { get; set; }
    }
}