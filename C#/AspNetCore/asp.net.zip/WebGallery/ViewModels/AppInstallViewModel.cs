﻿using WebGallery.Models;

namespace WebGallery.ViewModels
{
    public class AppInstallViewModel
    {
        public Submission Submission { get; set; }
        public SubmissionLocalizedMetaData Metadata { get; set; }
    }
}