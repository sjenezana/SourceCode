﻿namespace AzureGallery
{
    public class AzureStorageOptions
    {
        public string ConnectionString { get; set; }
        public string PackagesContainer { get; set; }
        public string TestResultsContainer { get; set; }
    }

    public class SendGridOptions
    {
        public string ApiKey { get; set; }
        public string From { get; set; }
        public string FromName { get; set; }
        public string To { get; set; }
        public string Cc { get; set; }
    }
}