﻿using System.IO;
using System.Net.Http;
using System.Threading.Tasks;

namespace AzureGallery.Utilities
{
    public class StreamHelper
    {
        public static async Task<FileInfo> DownloadFrom(string url, string filePath)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    using (var request = new HttpRequestMessage(HttpMethod.Get, url))
                    {
                        using (
                            Stream contentStream = await (await client.SendAsync(request)).Content.ReadAsStreamAsync(),
                            stream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None, 3145728, true))
                        {
                            await contentStream.CopyToAsync(stream);
                            return new FileInfo(filePath);
                        }
                    }
                }
            }
            catch
            {
                return null;
            }
        }
    }
}