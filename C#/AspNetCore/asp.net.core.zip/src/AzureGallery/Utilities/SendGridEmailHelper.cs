﻿using SendGrid;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;

namespace AzureGallery.Utilities
{
    public class SendGridEmailHelper
    {
        // Steps to generate SendGrid Api key
        // 1. Open the SendGrid service overview panel in Azure.
        // 2. Press "Manage" link at the top of SendGrid service overview page, and page will redirected to https://app.sendgrid.com/.
        // 3. Press "Settings" button in the left of the page, and it will expand with many links, the link "API Keys" will show.
        // 4. Press "API Keys" link and it will show all of the generated API Key.
        // 5. Press "Create API Key" in the right top of the page, then choose General API Key.
        // 6. Fill the name blank and choose the access authorities of each email service for this API key you want grant. 
        // 7.Then press "Save", API Key will be generated.

        public static void SendAsync(string apikey, string subject, string body, string from, string fromName, string to)
        {
            SendAsync(apikey, subject, body, from, fromName, to, null);
        }

        public static void SendAsync(string apiKey, string subject, string body, string from, string fromName, string to, string cc)
        {
            var transportWeb = new Web(apiKey);
            transportWeb.DeliverAsync(CreateMessage(subject, body, from, fromName, to, cc));
        }

        public static SendGridMessage CreateMessage(string subject, string body, string from, string fromName, string to, string cc)
        {
            if (string.IsNullOrWhiteSpace(to)) throw new ArgumentException($"Invalid argument: {nameof(to)}");
            if (string.IsNullOrWhiteSpace(from)) throw new ArgumentException($"Invalid argument: {nameof(from)}");
            if (string.IsNullOrWhiteSpace(subject)) throw new ArgumentException($"Invalid argument: {nameof(subject)}");
            if (string.IsNullOrWhiteSpace(body)) throw new ArgumentException($"Invalid argument: {nameof(body)}");

            var message = new SendGridMessage();
            message.Subject = subject;
            message.Html = body;
            message.From = new MailAddress(from, fromName);
            message.AddTo(SplitMailAddress(to));
            if (!string.IsNullOrWhiteSpace(cc))
                message.Cc = SplitMailAddress(cc).Select(s => new MailAddress(s)).ToArray();

            return message;
        }

        private static IEnumerable<string> SplitMailAddress(string addresses)
        {
            return addresses.Trim().Replace(';', ',').Trim(',').Split(',').Distinct().Where(e => !string.IsNullOrWhiteSpace(e));
        }
    }
}