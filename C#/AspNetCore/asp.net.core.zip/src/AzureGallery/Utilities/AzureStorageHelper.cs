﻿using Microsoft.AspNetCore.Http;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System.Threading.Tasks;

namespace AzureGallery.Utilities
{
    public static class AzureStorageHelper
    {
        public static void CreateContainerIfNotExists(string azureStorageConnectionString, string containerName)
        {
            var container = GetContainer(azureStorageConnectionString, containerName);

            // Create the container if it doesn't already exist
            container.CreateIfNotExistsAsync();

            // Enable blob-level public access
            container.SetPermissionsAsync(
                new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Blob });
        }

        public async static Task<string> Upload(string azureStorageConnectionString, string containerName, string blobName, IFormFile file)
        {
            using (var fileStream = file.OpenReadStream())
            {
                var container = GetContainer(azureStorageConnectionString, containerName);
                var blockBlob = container.GetBlockBlobReference(blobName);
                blockBlob.Properties.ContentType = file.ContentType;
                await blockBlob.UploadFromStreamAsync(fileStream);

                return blockBlob.Uri.ToString();
            }

        }

        public static void Delete(string azureStorageConnectionString, string containerName, string blobName)
        {
            var container = GetContainer(azureStorageConnectionString, containerName);

            // Retrieve reference to a blob
            var blockBlob = container.GetBlockBlobReference(blobName);

            // Delete the blob
            blockBlob.DeleteAsync();
        }

        private static CloudBlobContainer GetContainer(string azureStorageConnectionString, string containerName)
        {
            // Retrieve storage account from connection string
            var storageAccount = CloudStorageAccount.Parse(azureStorageConnectionString);

            // Create the blob client
            var blobClient = storageAccount.CreateCloudBlobClient();

            // Retrieve a reference to a container
            var container = blobClient.GetContainerReference(containerName);

            return container;
        }
    }
}