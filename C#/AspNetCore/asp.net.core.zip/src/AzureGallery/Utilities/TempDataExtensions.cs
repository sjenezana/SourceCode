﻿using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Newtonsoft.Json;

namespace AzureGallery.Utilities
{
    public static class TempDataExtensions
    {
        public static void Put<T>(this ITempDataDictionary TempData, string key, T value) where T : class
        {
            TempData[key] = JsonConvert.SerializeObject(value);
        }

        public static T Get<T>(this ITempDataDictionary TempData, string key) where T : class
        {
            object o;
            TempData.TryGetValue(key, out o);
            return o == null ? null : JsonConvert.DeserializeObject<T>((string)o);
        }

    }
}