﻿$(document).ready(function () {
    $.ajax({
        type: "POST",
        url: '/certrequests/' + $("#Id").val() + '/package/verify',
        dataType: "json",
        data: {
            packageUrl: $("#PackageUrl").val()
        },
        error: function (xhr, status, error) {
            $("#tip-panel").empty();
            $("#tip-panel").attr("class", "validate-fail");
            $("#tip-panel").append("<p>Can't make valiation for some resons. Status:" + xhr.statusCode + "</p>");
        }
    }).done(function (result) {
        var validation = result.packageValidation;
        if (validation.result == true) {
            $("#tip-panel").empty();
            $("#tip-panel").attr("class", "validate-pass");
            $("#tip-panel").append("<p>Validating passed, you can submit it for futher evaluation.</p>");
            $(".control-panel form").attr("style", "display:display");
        }
        else {
            $("#tip-panel").empty();
            $("#tip-panel").attr("class", "validate-fail");
            $("#tip-panel").append("<p>Validating fail, please fix these errors according to the details below.</p>");
            $(".control-panel a").attr("style", "display:display");
        }
        var html = '<table><thead><tr><th>Status</th><th>File Name</th><th>Field</th><th>Value</th></tr><thead><tbody>';
        for (var i = 0; i < validation.validationItems.length; i++) {
            var item = validation.validationItems[i];
            var status = item.status.name;
            var fileName = item.fileName;
            var field = item.field;
            var message = item.message;
            html += '<tr class ="status-' + status + '"><td>' + status + '</td><td>' + fileName + '</td><td>' + field + '</td><td>' + message + '</td></tr>';
        }
        html += '</tbody></table>';
        $(".result-panel").append(html);
    });
})