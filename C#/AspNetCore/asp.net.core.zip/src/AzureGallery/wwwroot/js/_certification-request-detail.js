﻿$(document).ready(function () {
    // disable add comment button while there is no word in the textarea
    $('.comment-edit-panel dl dd form textarea').change(function () {
        if ($(this).val().trim() != '') $(this).next().removeAttr('disabled');
        else $(this).next().attr('disabled', 'disabled');
    });

    $('.reply-edit-panel textarea').change(function () {
        if ($(this).val().trim() != '' && $(this).val().length < 1000) $(this).next().find('input[type="button"][value="Submit"]').removeAttr('disabled');
        else $(this).next().find('input[type="button"][value="Submit"]').attr('disabled', 'disabled');
    });

    BindEventsForReplyBtns($('.comments-list'));
    BindEventsForDeleteBtns($('.comments-list'));
    BindEventsForSubmitBtns($('.comments-list'));
    BindEnventsForCancelBtns($('.comments-list'));
})

// show reply textarea while user press "reply"
function BindEventsForReplyBtns(scope) {
    scope.find('input[type="button"][value="Reply"]').click(function () {
        var replyAuthor = $(this).closest('dd').prev().text().trim();
        var editPanel = $(this).closest('.comment-panel').find('.reply-edit-panel');
        editPanel.find('textarea').text('Reply to ' + replyAuthor + ' ');
        editPanel.attr('style', '');
    });
}

// delete comments and replies
function BindEventsForDeleteBtns(scope) {
    scope.find('input[type="button"][value="Delete"]').click(function () {
        var id = $(this).siblings('input[type="hidden"]').val();
        var contentPanel = $(this).closest('dd');
        var authorNamePanel = contentPanel.prev();
        $.ajax({
            type: 'POST',
            url: '/certrequests/comments/' + id + '/delete',
        }).done(function (result) {
            if (result.success) {
                authorNamePanel.remove();
                contentPanel.remove();
            }
        });
    });
}

// submit replying
function BindEventsForSubmitBtns(scope) {
    scope.find('input[type="button"][value="Submit"]').click(function () {
        var id = $(this).parent().siblings('input[type="hidden"][name="commentId"]').val();
        var name = $(this).parent().siblings('input[type="hidden"][name="authorName"]').val();
        var textarea = $(this).parent().siblings('textarea');
        var content = textarea.text();
        var messagePanel = $(this).siblings('span');
        var replyList = $(this).closest('.reply-edit-panel').siblings('dl');
        var replyEditPanel = $(this).closest('.reply-edit-panel');
        $.ajax({
            type: 'POST',
            url: '/certrequests/comments/' + id + '/reply',
            dataType: 'json',
            data: {
                content: content
            }
        }).done(function (result) {
            if (result.success) {
                var html = '<dt>' + name + ':</dt>';
                html += '<dd><p>' + content + '</p>';
                html += '<div class="reply-info-panel"><input type="hidden" value="' + result.replyId + '" />';
                html += '<span>' + result.time + '</span>';
                html += '<input type="button" class="btn-link" value="Reply" /><input type="button" class="btn-link" value="Delete" /></div></dd>';
                replyList.append(html);

                var scope = replyList.last('dd');
                BindEventsForReplyBtns(scope);
                BindEventsForDeleteBtns(scope);
                BindEventsForSubmitBtns(scope);
                BindEnventsForCancelBtns(scope);

                textarea.empty();
                replyEditPanel.attr('style', 'display: none;');
            }
            else {
                messagePanel.text('This comment has been deleted.');
            }
        });
    });
}

// Cancel replying
function BindEnventsForCancelBtns(scope) {
    scope.find('input[type="button"][value="Cancel"]').click(function () {
        $(this).parent().siblings('textarea').empty();
        $(this).closest('.reply-edit-panel').attr('style', 'display: none;');
    });
}