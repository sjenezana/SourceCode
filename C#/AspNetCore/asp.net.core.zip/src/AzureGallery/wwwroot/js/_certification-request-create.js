﻿$(document).ready(function () {
    if ($("#CertificationRequest_HasMsResource").is(":checked")) {
        $("#ms-resource-name").attr("style", "display:display");
        $("#ms-resource-email").attr("style", "display:display");
    }

    // disable mutiple choosing for framework and database
    $('select[name="FrameworkIds"]').removeAttr("multiple");
    $('select[name="DatabaseIds"]').removeAttr("multiple");

    jQuery.validator.setDefaults({
        ignore: []
    });

    // Conditional validation for Ms resource
    jQuery.validator.addMethod("msresource", function (value, element, params) {
        return !$("#CertificationRequest_HasMsResource").is(":checked") || value.trim() != "";
    }, "");

    jQuery.validator.unobtrusive.adapters.add('msresource', [], function (options) {
        options.rules['msresource'] = [];
        options.messages['msresource'] = options.message;
    });

    // Validation for terms agreeement
    jQuery.validator.addMethod("agreeterms", function (value, element, params) {
        return $(element).is(":checked");
    }, "");

    jQuery.validator.unobtrusive.adapters.add('agreeterms', [], function (options) {
        options.rules['agreeterms'] = [];
        options.messages['agreeterms'] = options.message;
    });

    // Hide and show Ms resource panel
    $("#CertificationRequest_HasMsResource").click(function () {
        if ($(this).is(":checked")) {
            $("#ms-resource-name").attr("style", "display:display");
            $("#ms-resource-email").attr("style", "display:display");
        }
        else {
            $("#CertificationRequest_MicrosoftResourceName").val(null);
            $("#CertificationRequest_MicrosoftResourceEmail").val(null);
            $("#ms-resource-name").attr("style", "display:none");
            $("#ms-resource-email").attr("style", "display:none");
        }
    });

    //ajax file upload
    $("#package-file-upload-btn").click(function () {
        ClearPackageUploadResultPanel();
        if ($("#package-file").val().replace(/^.*\./, '').toLowerCase() != "zip") {
            $("#package-upload-result-panel").append('<p class="text-danger">Only zip file is allowed.</p>');
        }
        else {
            $("#package-upload-result-panel").addClass("upload-uploading");
            $("#package-upload-result-panel").append("<p>Uploading...</p>");
            var fileUpload = $("#package-file").get(0);
            var files = fileUpload.files;
            var data = new FormData();
            for (var i = 0; i < files.length ; i++) {
                data.append($("#CertificationRequest_Id").val() + "-package." + $("#package-file").val().replace(/^.*\./, ''), files[i]);
            }
            $.ajax({
                type: "POST",
                url: "/certrequests/file/upload",
                contentType: false,
                processData: false,
                data: data,
                error: function (xhr, status, error) {
                    ClearPackageUploadResultPanel();
                    $("#package-upload-result-panel").addClass("upload-fail");
                    $("#package-upload-result-panel").append('<p>Upload faild.</p>');
                }
            }).done(function (result) {
                ClearPackageUploadResultPanel();
                if (result.successOrNot == true) {
                    $("#package-upload-result-panel").addClass("upload-succeed");
                    $("#package-upload-result-panel").append('<p>Upload succeed.</p>');
                    $("#CertificationRequest_PackageUrl").val(result.url);
                    $("#package-uploaded-tip a").attr("href", result.url);
                    $("#no-package-tip").attr("style", "display:none");
                    $("#package-uploaded-tip").attr("style", "display:display");
                    $("#submit-form").validate().element("#CertificationRequest_PackageUrl");
                }
                else {
                    $("#package-upload-result-panel").addClass("upload-fail");
                    $("#package-upload-result-panel").append('<p>Upload faild.</p>');
                }
            });
        }
    });

    $("#testresult-file-upload-btn").click(function () {
        ClearTestResultUploadResultPanel();
        var allowedExtensions = ["doc", "docm", "docx", "xlt", "xls", "xml", "xlsx", "csv"];
        if (allowedExtensions.indexOf($("#testresult-file").val().replace(/^.*\./, '').toLowerCase()) < 0) {
            $("#testresult-upload-result-panel").append('<p class="text-danger">Only word or excel file is allowed.</p>');
        }
        else {
            $("#testresult-upload-result-panel").addClass("upload-uploading");
            $("#testresult-upload-result-panel").append("<p>Uploading...</p>");
            var fileUpload = $("#testresult-file").get(0);
            var files = fileUpload.files;
            var data = new FormData();
            for (var i = 0; i < files.length ; i++) {
                data.append($("#CertificationRequest_Id").val() + "-testresult." + $("#testresult-file").val().replace(/^.*\./, ''), files[i]);
            }
            $.ajax({
                type: "POST",
                url: "/certrequests/file/upload",
                contentType: false,
                processData: false,
                data: data,
                error: function (xhr, status, error) {
                    ClearTestResultUploadResultPanel();
                    $("#testresult-upload-result-panel").addClass("upload-fail");
                    $("#testresult-upload-result-panel").append('<p>Upload faild.</p>');
                }
            }).done(function (result) {
                ClearTestResultUploadResultPanel();
                if (result.successOrNot == true) {
                    $("#testresult-upload-result-panel").addClass("upload-succeed");
                    $("#testresult-upload-result-panel").append('<p>Upload succeed.</p>');
                    $("#CertificationRequest_TestResultUrl").val(result.url);
                    $("#testresult-uploaded-tip a").attr("href", result.url);
                    $("#no-testresult-tip").attr("style", "display:none");
                    $("#testresult-uploaded-tip").attr("style", "display:display");
                    $("#submit-form").validate().element("#CertificationRequest_TestResultUrl");
                }
                else {
                    $("#testresult-upload-result-panel").addClass("upload-fail");
                    $("#testresult-upload-result-panel").append('<p>Upload faild.</p>');
                }
            });
        }
    });
}(jQuery));

function ClearPackageUploadResultPanel() {
    $("#package-upload-result-panel").attr("class", "");
    $("#package-upload-result-panel").empty();
}

function ClearTestResultUploadResultPanel() {
    $("#testresult-upload-result-panel").attr("class", "");
    $("#testresult-upload-result-panel").empty();
}