﻿$(document).ready(function () {
    $('#grant-new-btn').click(function () {
        $(this).hide();
        $('.admin-add-panel').attr('style', '');
    });

    $('.admin-add-panel form').validate({
        rules: {
            "nickname": {
                required: true,
                maxlength: 100
            },
            "microsoftAccount": {
                required: true,
                email: true,
                maxlength: 100
            },
            "confirmation": {
                equalTo: "#microsoftAccount",
                maxlength: 100
            }
        }
    });

    $('.admin-add-panel input[type="button"][value="Cancel"]').click(function () {
        $(this).closest('form').find('input[type="text"]').val('');
        $(this).closest('div').attr('style', 'display: none;');
        $(this).closest('div').prev().show();
    });

    $('.table input[type="button"]').click(function () {
        var msAccount = $(this).parent().prev().text().trim();
        var columnToRemove = $(this).closest('tr');
        $.ajax({
            type: "POST",
            url: '/admin/superusers/remove',
            dataType: 'json',
            data: {
                microsoftAccount: msAccount
            }
        }).done(function (result) {
            if (result.success == true) {
                columnToRemove.remove();
            }
        })
    });
})