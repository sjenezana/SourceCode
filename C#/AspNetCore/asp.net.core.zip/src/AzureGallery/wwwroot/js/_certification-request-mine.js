﻿$(document).ready(function () {
    var table = $("#requests-table").dataTable({
        processing: true,
        serverSide: true,
        ajax: "/certrequests/mine",
        columns: [
            { data: "appName", orderable: true },
            { data: "companyName", orderable: true },
            { data: "updated", searchable: false, orderable: true },
            { data: "status", orderable: true },
            { data: "id", searchable: false, orderable: false }
        ],
        order: [[2, "desc"]]
    });

    table.on("draw.dt", function () {
        // add tooltip
        for (var i = 1; i < 3; i++) {
            $('#requests-table tbody tr td:nth-child(' + i + ')').each(function () {
                var text = $(this).text();
                $(this).attr("data-toggle", "tooltip");
                $(this).attr("title", text);
                $(this).text(toShort(text));
            })
        }

        // make app Name be the link
        $("#requests-table tbody tr td:first-child").each(function () {
            if ($(this).hasClass('dataTables_empty')) return;
            var id = $(this).siblings(':last').text();
            var text = $(this).text();
            $(this).html('<a href="/certrequests/' + id + '">' + text + '</a>');
        });

        // add action panel
        $("#requests-table tbody tr td:last-child").each(function () {
            if ($(this).hasClass('dataTables_empty')) return;
            var id = $(this).text();
            $(this).empty();

            $(this).append('<input type="button" value="action" class="btn-link" />');
            var html = '<div class="actions-panel" style="display: none"><ul>';
            html += '<li><a href="/certrequests/' + id + '/edit">Edit</a></li>';
            html += '<li><a href="/certrequests/' + id + '/verify">Verify</a></li>';
            html += '</ul></div>';
            $(this).append(html);

            var actionPanel = $(this).find('div');
            var link = $(this).find('input[value="action"]').get(0);
            if (link != null && actionPanel != null) {
                $(this).mouseenter(function () { showActions(link, actionPanel); });
                $(this).mouseleave(function () { actionPanel.hide(); });
            }
        });
    });
});

function showActions(target, panelActions) {
    var left = target.offsetWidth
        + target.offsetLeft
        + target.offsetParent.offsetLeft
        + target.offsetParent.offsetParent.offsetLeft;
    var top = target.offsetTop
        + target.offsetParent.offsetTop
        + target.offsetParent.offsetParent.offsetTop;
    panelActions.css({ left: left + "px", top: top + "px" });
    panelActions.show();
}

function toShort(string) {
    if (string.length > 30) {
        return string.substr(0, 30) + "...";
    }
    else {
        return string;
    }
}