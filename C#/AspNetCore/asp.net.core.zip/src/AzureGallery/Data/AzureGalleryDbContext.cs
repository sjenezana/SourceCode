﻿using AzureGallery.Models;
using Microsoft.EntityFrameworkCore;

namespace AzureGallery.Data
{
    public partial class AzureGalleryDbContext : DbContext
    {
        public AzureGalleryDbContext(DbContextOptions<AzureGalleryDbContext> options) : base(options)
        {
        }

        public DbSet<AppDatabase> AppDatabases { get; set; }
        public DbSet<AppFramework> AppFrameworks { get; set; }
        public DbSet<CertificationKind> CertificationKinds { get; set; }
        public DbSet<Comment> Comments { get; set; }
        public DbSet<Database> Databases { get; set; }
        public DbSet<Framework> Frameworks { get; set; }
        public DbSet<CertificationRequest> CertificationRequests { get; set; }
        public DbSet<CertificationRequestState> CertificationRequestStates { get; set; }
        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AppDatabase>().HasKey(s => new { s.CertificationRequestId, s.DatabaseId });

            modelBuilder.Entity<AppFramework>().HasKey(s => new { s.CertificationRequestId, s.FrameworkId });

            modelBuilder.Entity<User>().HasAlternateKey(c => c.MicrosoftAccount);
        }
    }
}
