﻿using AzureGallery.Models;
using System;
using System.Linq;

namespace AzureGallery.Data
{
    public partial class AzureGalleryDbContext
    {
        /// <summary>
        /// Inits frameworks, databases, certification kinds, and certification request states.
        /// </summary>
        internal void InitMetadata()
        {
            var now = DateTime.Now;

            if (!Frameworks.Any())
            {
                Frameworks.AddRange(new Framework[]
                {
                    new Framework { Name = ".NET", DisplayOrder= 1, CreatedTime= now, UpdatedTime = now },
                    new Framework { Name = "NodeJS", DisplayOrder= 2, CreatedTime= now, UpdatedTime = now },
                    new Framework { Name = "PHP", DisplayOrder= 3, CreatedTime= now, UpdatedTime = now },
                    new Framework { Name = "Python", DisplayOrder= 4, CreatedTime= now, UpdatedTime = now },
                    new Framework { Name = "Java", DisplayOrder= 5, CreatedTime= now, UpdatedTime = now },
                 });
            }

            if (!Databases.Any())
            {
                Databases.AddRange(new Database[]
                {
                    new Database { Name = "No database", DisplayOrder= 1, CreatedTime= now, UpdatedTime = now },
                    new Database { Name = "MySQL", DisplayOrder= 2, CreatedTime= now, UpdatedTime = now },
                    new Database { Name = "SQL DB", DisplayOrder= 3, CreatedTime= now, UpdatedTime = now },
                });
            }

            if (!CertificationKinds.Any())
            {
                CertificationKinds.AddRange(new CertificationKind[]
                {
                    new CertificationKind { Name = "Web Application on Azure app service", DisplayOrder = 1, CreatedTime = now, UpdatedTime = now },
                    new CertificationKind { Name = "Mobile Application  on Azure app service", DisplayOrder = 2, CreatedTime = now, UpdatedTime = now },
                });
            }

            if (!CertificationRequestStates.Any())
            {
                CertificationRequestStates.AddRange(new CertificationRequestState[]
                {
                   new CertificationRequestState { Name = "Validating", DisplayOrder = 1, CreatedTime = now, UpdatedTime = now, Description = "Validating means that a new certification request has been created and the validation result haven't been generated." },
                   new CertificationRequestState { Name = "Validating Passed", DisplayOrder = 2, CreatedTime = now, UpdatedTime = now, Description = "Validating Passed means that the certification request has passed the validation." },
                   new CertificationRequestState { Name = "Validating Failed", DisplayOrder = 3, CreatedTime = now, UpdatedTime = now, Description = "Validating Failed means that the certification request has failed the validation." },
                   new CertificationRequestState { Name = "Approved", DisplayOrder = 4, CreatedTime = now, UpdatedTime = now, Description = "Approved means that the PM approved the certification request." },
                   new CertificationRequestState { Name = "Rejected", DisplayOrder = 5, CreatedTime = now, UpdatedTime = now, Description = "Rejected means that the PM rejected the certification request." },
                   new CertificationRequestState { Name = "Published", DisplayOrder = 6, CreatedTime = now, UpdatedTime = now, Description = "Published means that certification request has been published." },
                   new CertificationRequestState { Name = "Hold", DisplayOrder = 7, CreatedTime = now, UpdatedTime = now, Description = "Hold means that the certification request need to be hold for some reasons." }
                });
            }

            SaveChanges();
        }
    }
}