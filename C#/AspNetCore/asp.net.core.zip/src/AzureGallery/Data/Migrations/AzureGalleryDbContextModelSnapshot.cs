﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using AzureGallery.Data;

namespace AzureGallery.Data.Migrations
{
    [DbContext(typeof(AzureGalleryDbContext))]
    partial class AzureGalleryDbContextModelSnapshot : ModelSnapshot
    {
        protected override void BuildModel(ModelBuilder modelBuilder)
        {
            modelBuilder
                .HasAnnotation("ProductVersion", "1.0.1")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            modelBuilder.Entity("AzureGallery.Models.AppDatabase", b =>
                {
                    b.Property<Guid>("CertificationRequestId");

                    b.Property<Guid>("DatabaseId");

                    b.HasKey("CertificationRequestId", "DatabaseId");

                    b.HasIndex("CertificationRequestId");

                    b.HasIndex("DatabaseId");

                    b.ToTable("AppDatabases");
                });

            modelBuilder.Entity("AzureGallery.Models.AppFramework", b =>
                {
                    b.Property<Guid>("CertificationRequestId");

                    b.Property<Guid>("FrameworkId");

                    b.HasKey("CertificationRequestId", "FrameworkId");

                    b.HasIndex("CertificationRequestId");

                    b.HasIndex("FrameworkId");

                    b.ToTable("AppFrameworks");
                });

            modelBuilder.Entity("AzureGallery.Models.CertificationKind", b =>
                {
                    b.Property<Guid>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<DateTime>("CreatedTime");

                    b.Property<string>("Description")
                        .HasAnnotation("MaxLength", 500);

                    b.Property<int>("DisplayOrder");

                    b.Property<string>("Name")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 200);

                    b.Property<DateTime>("UpdatedTime");

                    b.HasKey("Id");

                    b.ToTable("CertificationKinds");
                });

            modelBuilder.Entity("AzureGallery.Models.CertificationRequest", b =>
                {
                    b.Property<Guid>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("AppDescription")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 1000);

                    b.Property<string>("AppName")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 200);

                    b.Property<Guid>("CertificationKindId");

                    b.Property<Guid?>("CertificationRequestStateId");

                    b.Property<string>("CertificationScenario")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 1000);

                    b.Property<string>("CompanyDescription")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 1000);

                    b.Property<string>("CompanyName")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 200);

                    b.Property<string>("CompanyUrl")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 200);

                    b.Property<string>("ContactEmail")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 200);

                    b.Property<string>("ContactName")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 200);

                    b.Property<string>("ContactRole")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 200);

                    b.Property<DateTime>("CreatedTime");

                    b.Property<bool>("HasMsResource");

                    b.Property<string>("MicrosoftPartnerNetworkID")
                        .HasAnnotation("MaxLength", 200);

                    b.Property<string>("MicrosoftResourceEmail")
                        .HasAnnotation("MaxLength", 200);

                    b.Property<string>("MicrosoftResourceName")
                        .HasAnnotation("MaxLength", 200);

                    b.Property<Guid?>("OwnerId");

                    b.Property<string>("PackageUrl")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 200);

                    b.Property<string>("PublisherID")
                        .HasAnnotation("MaxLength", 200);

                    b.Property<string>("TestResultUrl")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 200);

                    b.Property<DateTime>("UpdatedTime");

                    b.HasKey("Id");

                    b.HasIndex("CertificationKindId");

                    b.HasIndex("CertificationRequestStateId");

                    b.HasIndex("OwnerId");

                    b.ToTable("CertificationRequests");
                });

            modelBuilder.Entity("AzureGallery.Models.CertificationRequestState", b =>
                {
                    b.Property<Guid>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<DateTime>("CreatedTime");

                    b.Property<string>("Description")
                        .HasAnnotation("MaxLength", 500);

                    b.Property<int>("DisplayOrder");

                    b.Property<string>("Name")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 200);

                    b.Property<DateTime>("UpdatedTime");

                    b.HasKey("Id");

                    b.ToTable("CertificationRequestStates");
                });

            modelBuilder.Entity("AzureGallery.Models.Comment", b =>
                {
                    b.Property<Guid>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<Guid>("AuthorId");

                    b.Property<Guid?>("CertificationRequestId");

                    b.Property<Guid?>("CommentId");

                    b.Property<string>("Content")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 2000);

                    b.Property<DateTime>("CreatedTime");

                    b.Property<DateTime>("UpdatedTime");

                    b.HasKey("Id");

                    b.HasIndex("AuthorId");

                    b.HasIndex("CertificationRequestId");

                    b.HasIndex("CommentId");

                    b.ToTable("Comments");
                });

            modelBuilder.Entity("AzureGallery.Models.Database", b =>
                {
                    b.Property<Guid>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<DateTime>("CreatedTime");

                    b.Property<int>("DisplayOrder");

                    b.Property<string>("Name")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 200);

                    b.Property<DateTime>("UpdatedTime");

                    b.HasKey("Id");

                    b.ToTable("Databases");
                });

            modelBuilder.Entity("AzureGallery.Models.Framework", b =>
                {
                    b.Property<Guid>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<DateTime>("CreatedTime");

                    b.Property<int>("DisplayOrder");

                    b.Property<string>("Name")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 200);

                    b.Property<DateTime>("UpdatedTime");

                    b.HasKey("Id");

                    b.ToTable("Frameworks");
                });

            modelBuilder.Entity("AzureGallery.Models.User", b =>
                {
                    b.Property<Guid>("Id")
                        .ValueGeneratedOnAdd();

                    b.Property<DateTime>("CreatedTime");

                    b.Property<string>("EmailAddress")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 200);

                    b.Property<bool>("IsAdmin");

                    b.Property<string>("MicrosoftAccount")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 200);

                    b.Property<string>("Nickname")
                        .IsRequired()
                        .HasAnnotation("MaxLength", 200);

                    b.Property<DateTime>("UpdatedTime");

                    b.HasKey("Id");

                    b.HasAlternateKey("MicrosoftAccount");

                    b.ToTable("Users");
                });

            modelBuilder.Entity("AzureGallery.Models.AppDatabase", b =>
                {
                    b.HasOne("AzureGallery.Models.CertificationRequest", "CertificationRequest")
                        .WithMany("AppDatabases")
                        .HasForeignKey("CertificationRequestId")
                        .OnDelete(DeleteBehavior.Cascade);

                    b.HasOne("AzureGallery.Models.Database", "Database")
                        .WithMany()
                        .HasForeignKey("DatabaseId")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("AzureGallery.Models.AppFramework", b =>
                {
                    b.HasOne("AzureGallery.Models.CertificationRequest", "CertificationRequest")
                        .WithMany("AppFrameworks")
                        .HasForeignKey("CertificationRequestId")
                        .OnDelete(DeleteBehavior.Cascade);

                    b.HasOne("AzureGallery.Models.Framework", "Framework")
                        .WithMany()
                        .HasForeignKey("FrameworkId")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("AzureGallery.Models.CertificationRequest", b =>
                {
                    b.HasOne("AzureGallery.Models.CertificationKind", "CertificationKind")
                        .WithMany()
                        .HasForeignKey("CertificationKindId")
                        .OnDelete(DeleteBehavior.Cascade);

                    b.HasOne("AzureGallery.Models.CertificationRequestState", "CertificationRequestState")
                        .WithMany()
                        .HasForeignKey("CertificationRequestStateId");

                    b.HasOne("AzureGallery.Models.User", "Owner")
                        .WithMany("CertificationRequests")
                        .HasForeignKey("OwnerId");
                });

            modelBuilder.Entity("AzureGallery.Models.Comment", b =>
                {
                    b.HasOne("AzureGallery.Models.User", "Author")
                        .WithMany()
                        .HasForeignKey("AuthorId")
                        .OnDelete(DeleteBehavior.Cascade);

                    b.HasOne("AzureGallery.Models.CertificationRequest", "CertificationRequest")
                        .WithMany("Comments")
                        .HasForeignKey("CertificationRequestId");

                    b.HasOne("AzureGallery.Models.Comment")
                        .WithMany("Replies")
                        .HasForeignKey("CommentId");
                });
        }
    }
}
