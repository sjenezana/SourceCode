﻿using AzureGallery.Data;
using AzureGallery.Mvc;
using AzureGallery.Mvc.Routing;
using AzureGallery.Mvc.Security;
using AzureGallery.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace AzureGallery
{
    public class Startup
    {
        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true);

            if (env.IsDevelopment())
            {
                // For more details on using the user secret store see http://go.microsoft.com/fwlink/?LinkID=532709
                builder.AddUserSecrets();

                // This will push telemetry data through Application Insights pipeline faster, allowing you to view results immediately.
                builder.AddApplicationInsightsSettings(developerMode: true);
            }

            builder.AddEnvironmentVariables();
            Configuration = builder.Build();
        }

        public IConfigurationRoot Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // Add framework services.
            services.AddApplicationInsightsTelemetry(Configuration);

            // Add DbContext.
            services.AddDbContext<AzureGalleryDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

            // Add custom view location formats.
            services.AddMvc(options => { options.Filters.Add(new RequireHttpsAttribute()); })
                .AddRazorOptions(options =>
                {
                    options.ViewLocationFormats.Clear();
                    options.ViewLocationFormats.Add("/Mvc/Views/{0}.cshtml");
                    options.ViewLocationFormats.Add("/Mvc/Views/Shared/{0}.cshtml");
                    options.ViewLocationFormats.Add("/Mvc/Views/{1}/{0}.cshtml");
                });

            // Add application services.
            services.AddTransient<IUserService, UserService>();
            services.AddTransient<IMetadataService, MetadataService>();
            services.AddTransient<ICertificationRequestService, CeritificationRequestService>();
            services.AddTransient<IAureStorageService, AzureStorageSerivce>();
            services.AddTransient<IEmailService, EmailService>();

            // Add CookieTempDataProvider after AddMvc and include ViewFeatures.
            services.AddTransient<ITempDataProvider, CookieTempDataProvider>();
            
            // Add Configuratuion options
            services.Configure<AzureStorageOptions>(Configuration.GetSection("AzureStorage"));
            services.Configure<SendGridOptions>(Configuration.GetSection("SendGrid"));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();
            loggerFactory.WithFilter(new FilterLoggerSettings {
                 { "Default", LogLevel.Error },
                 { "Microsoft", LogLevel.Error },
                 { "System", LogLevel.Error },
                }).AddAzureWebAppDiagnostics();

            app.UseApplicationInsightsRequestTelemetry();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseDatabaseErrorPage();
                app.UseBrowserLink();
            }
            else
            {
                app.UseExceptionHandler("/error");
            }

            app.UseStatusCodePagesWithReExecute("/error/status/{0}");

            // !! Exception middleware for application insight should be added after error page and any other error handling middleware
            // See: https://github.com/Microsoft/ApplicationInsights-aspnetcore/wiki/Getting-Started
            app.UseApplicationInsightsExceptionTelemetry();

            app.UseStaticFiles();

            app.UseMicrosoftAccountAuthentication(
                Configuration["Authentication:ClientId"],
                Configuration["Authentication:ClientSecret"]);

            app.RegisterRoutes();

            app.InitAzureGalleryDbContext();
        }
    }
}