﻿using AzureGallery.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace AzureGallery.Models
{
    public class CertificationRequest : Entity
    {
        [Required(AllowEmptyStrings = false)]
        [StringLength(200)]
        [RegularExpression("^[0-9A-Za-z ,.]+$", ErrorMessage = "Only alphanumeric characters, dot and comma are allowed.")]
        [Display(Name = "Company Name")]
        public string CompanyName { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(1000)]
        [RegularExpression("^[0-9A-Za-z ,.]+$", ErrorMessage = "Only alphanumeric characters, dot and comma are allowed.")]
        [Display(Name = "Company Description")]
        public string CompanyDescription { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(200)]
        [Url]
        [Display(Name = "Company URL")]
        public string CompanyUrl { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(200)]

        [RegularExpression("^[0-9A-Za-z ]+$", ErrorMessage = "Only alphanumeric characters are allowed.")]
        [Display(Name = "Contact Name")]
        public string ContactName { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(200)]
        [EmailAddress]
        [Display(Name = "Email")]
        public string ContactEmail { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(200)]
        [RegularExpression("^[0-9A-Za-z ]+$", ErrorMessage = "Only alphanumeric characters are allowed.")]
        [Display(Name = "Role")]
        public string ContactRole { get; set; }

        public bool HasMsResource { get; set; }

        [StringLength(200)]
        [MsResource(nameof(HasMsResource), "Resource Name is required.")]
        [RegularExpression("^[0-9A-Za-z ]+$", ErrorMessage = "Only alphanumeric characters are allowed.")]
        [Display(Name = "Resource Name")]
        public string MicrosoftResourceName { get; set; }

        [StringLength(200)]
        [EmailAddress]
        [RegularExpression(@".*@microsoft.com\b", ErrorMessage = "Resource Email must ends with @microsft.com.")]
        [MsResource(nameof(HasMsResource), "Resource Email is required.")]
        [Display(Name = "Resource Email")]
        public string MicrosoftResourceEmail { get; set; }

        [StringLength(200)]
        [Display(Name = "Microsoft Partner Network ID ")]
        public string MicrosoftPartnerNetworkID { get; set; }

        [StringLength(200)]
        [Display(Name = "Publisher ID")]
        public string PublisherID { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(200)]
        [RegularExpression("^[0-9A-Za-z ]+$", ErrorMessage = "Only alphanumeric characters are allowed.")]
        [Display(Name = "App Name")]
        public string AppName { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(1000)]
        [RegularExpression("^[0-9A-Za-z ,.]+$", ErrorMessage = "Only alphanumeric characters, dot and comma are allowed.")]
        [Display(Name = "App Description")]
        public string AppDescription { get; set; }

        public ICollection<AppFramework> AppFrameworks { get; set; }

        public ICollection<AppDatabase> AppDatabases { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Package needs to be uploaded.")]
        [StringLength(200)]
        public string PackageUrl { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Test Result needs to be uploaded.")]
        [StringLength(200)]
        public string TestResultUrl { get; set; }

        [Required(ErrorMessage = "Please choose the certification kind your want apply.")]
        public Guid CertificationKindId { get; set; }

        public CertificationKind CertificationKind { get; set; }

        [Required]
        [StringLength(1000)]
        [RegularExpression("^[0-9A-Za-z ,.]+$", ErrorMessage = "Only alphanumeric characters, dot and comma are allowed.")]
        public string CertificationScenario { get; set; }

        public CertificationRequestState CertificationRequestState { get; set; }

        public ICollection<Comment> Comments { get; set; }

        public User Owner { get; set; }

        public CertificationRequest()
        {
            Id = Guid.NewGuid();
        }
    }
}