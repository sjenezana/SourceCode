﻿using System;
using System.ComponentModel.DataAnnotations;

namespace AzureGallery.Models
{
    public class AppFramework
    {
        [Required]
        public Guid CertificationRequestId { get; set; }

        [Required]
        public Guid FrameworkId { get; set; }

        public CertificationRequest CertificationRequest { get; set; }

        public Framework Framework { get; set; }
    }
}
