﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace AzureGallery.Models
{
    public class Comment : Entity
    {
        [Required(AllowEmptyStrings = false)]
        [StringLength(2000)]
        public string Content { get; set; }

        public CertificationRequest CertificationRequest { get; set; }

        [Required]
        public Guid AuthorId { get; set; }

        public User Author { get; set; }

        public ICollection<Comment> Replies { get; set; }
    }
}
