﻿using System.ComponentModel.DataAnnotations;

namespace AzureGallery.Models
{
    public class Framework : OrderableEntity
    {
        [Required]
        [StringLength(200)]
        public string Name { get; set; }
    }
}