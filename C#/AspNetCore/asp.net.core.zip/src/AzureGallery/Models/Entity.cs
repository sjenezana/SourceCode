﻿using System;
using System.ComponentModel.DataAnnotations;

namespace AzureGallery.Models
{
    public abstract class Entity
    {
        [Key]
        public Guid Id { get; set; }
        public DateTime CreatedTime { get; set; }
        public DateTime UpdatedTime { get; set; }
    }

    public abstract class OrderableEntity : Entity
    {
        public int DisplayOrder { get; set; }
    }
}
