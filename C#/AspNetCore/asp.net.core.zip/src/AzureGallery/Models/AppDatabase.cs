﻿using System;
using System.ComponentModel.DataAnnotations;

namespace AzureGallery.Models
{
    public class AppDatabase
    {
        [Required]
        public Guid CertificationRequestId { get; set; }

        [Required]
        public Guid DatabaseId { get; set; }

        public CertificationRequest CertificationRequest { get; set; }

        public Database Database { get; set; }
    }
}
