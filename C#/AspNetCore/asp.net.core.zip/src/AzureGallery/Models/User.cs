﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace AzureGallery.Models
{
    public class User : Entity
    {
        public bool IsAdmin { get; set; }

        [Required]
        [StringLength(200)]
        public string MicrosoftAccount { get; set; }

        [Required]
        [StringLength(200)]
        public string EmailAddress { get; set; }

        [Required]
        [StringLength(200)]
        public string Nickname { get; set; }

        public ICollection<CertificationRequest> CertificationRequests { get; set; }
    }
}
