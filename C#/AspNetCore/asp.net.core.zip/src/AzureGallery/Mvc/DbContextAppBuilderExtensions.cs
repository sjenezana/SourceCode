﻿using AzureGallery.Data;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

namespace AzureGallery.Mvc
{
    public static class DbContextAppBuilderExtensions
    {
        public static void InitAzureGalleryDbContext(this IApplicationBuilder app)
        {
            var context = app.ApplicationServices.GetService<AzureGalleryDbContext>();
            context.Database.EnsureCreated();
            context.InitMetadata();
        }
    }
}