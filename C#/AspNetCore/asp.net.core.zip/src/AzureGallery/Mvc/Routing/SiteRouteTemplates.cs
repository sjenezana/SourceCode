﻿namespace AzureGallery.Mvc.Routing
{
    public class SiteRouteUrlTemplates
    {
        public const string Home = "";
        public const string Benefits = "benefits";
        public const string Process = "process";

        public const string Error = "error";
        public const string Error_Status_Code = "error/status/{statusCode}";
        public const string Error_Fire = "error/fire";

        public const string SignIn = "signin";
        public const string SignOut = "signout";

        public const string Portal = "portal";
        public const string Certification_Request_Mine = "certrequests/mine";
        public const string Certification_Request_Create = "certification/request";
        public const string Certification_Request_Submit = "certrequests/{id}/submit";
        public const string Certification_Request_Edit = "certrequests/{id}/edit";
        public const string Certification_Request_Verify = "certrequests/{id}/verify";
        public const string Certification_Request_Package_Verify = "certrequests/{id}/package/verify";
        public const string Certification_Request_View = "certrequests/{id}";
        public const string Certification_Request_Comment_Add = "certrequests/{id}/comments/add";
        public const string Certification_Request_Comment_Delete = "certrequests/comments/{id}/delete";
        public const string Certification_Request_Comment_Reply = "certrequests/comments/{id}/reply";
        public const string Certification_Request_Notify = "certrequests/{id}/notify";
        public const string Certification_Request_Email = "certrequests/{id}/email";
        public const string Certification_Request_File_Upload = "certrequests/file/upload";

        public const string Admin = "admin";
        public const string Admin_Portal = "admin/dashboard";
        public const string Admin_Certification_Request_All = "admin/certrequests";
        public const string Admin_Certification_Request_Status_Change = "admin/certrequests/{id}/status/change";
        public const string Admin_Superusers = "admin/superusers";
        public const string Admin_Superusers_Grant = "admin/superusers/grant";
        public const string Admin_Superusers_Remove = "admin/superusers/remove";
    }
}