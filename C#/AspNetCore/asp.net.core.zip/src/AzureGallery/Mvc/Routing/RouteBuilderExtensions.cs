﻿using AzureGallery.Mvc.Controllers;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;

namespace AzureGallery.Mvc.Routing
{
    public static class RouteBuilderExtensions
    {
        public static IApplicationBuilder RegisterRoutes(this IApplicationBuilder app)
        {
            app.UseMvc(MapRoutes);

            return app;
        }

        public static void MapRoutes(IRouteBuilder routes)
        {
            var home = nameof(HomeController).Replace("Controller", string.Empty);
            routes.MapRoute(name: SiteRouteNames.Home, template: SiteRouteUrlTemplates.Home, defaults: new { controller = home, action = nameof(HomeController.Index) });
            routes.MapRoute(name: SiteRouteNames.Benefits, template: SiteRouteUrlTemplates.Benefits, defaults: new { controller = home, action = nameof(HomeController.Benefits) });
            routes.MapRoute(name: SiteRouteNames.Process, template: SiteRouteUrlTemplates.Process, defaults: new { controller = home, action = nameof(HomeController.Process) });

            routes.MapRoute(name: SiteRouteNames.Error, template: SiteRouteUrlTemplates.Error, defaults: new { controller = home, action = nameof(HomeController.Error) });
            routes.MapRoute(name: SiteRouteNames.Error_Status_Code, template: SiteRouteUrlTemplates.Error_Status_Code, defaults: new { controller = home, action = nameof(HomeController.HandleStatusCode) });
            routes.MapRoute(name: SiteRouteNames.Error_Fire, template: SiteRouteUrlTemplates.Error_Fire, defaults: new { controller = home, action = nameof(HomeController.Fire) });

            var account = nameof(AccountController).Replace("Controller", string.Empty);
            routes.MapRoute(name: SiteRouteNames.SignIn, template: SiteRouteUrlTemplates.SignIn, defaults: new { controller = account, action = nameof(AccountController.SignIn) });
            routes.MapRoute(name: SiteRouteNames.SignOut, template: SiteRouteUrlTemplates.SignOut, defaults: new { controller = account, action = nameof(AccountController.SignOut) });

            var certificationRequest = nameof(CertificationRequestController).Replace("Controller", string.Empty);
            routes.MapRoute(name: SiteRouteNames.Portal, template: SiteRouteUrlTemplates.Portal, defaults: new { controller = certificationRequest, action = nameof(CertificationRequestController.Portal) });
            routes.MapRoute(name: SiteRouteNames.Certification_Request_Mine, template: SiteRouteUrlTemplates.Certification_Request_Mine, defaults: new { controller = certificationRequest, action = nameof(CertificationRequestController.GetMyRequests) });
            routes.MapRoute(name: SiteRouteNames.Certification_Request_Create, template: SiteRouteUrlTemplates.Certification_Request_Create, defaults: new { controller = certificationRequest, action = nameof(CertificationRequestController.Create) });
            routes.MapRoute(name: SiteRouteNames.Certification_Request_Submit, template: SiteRouteUrlTemplates.Certification_Request_Submit, defaults: new { controller = certificationRequest, action = nameof(CertificationRequestController.Submit) });
            routes.MapRoute(name: SiteRouteNames.Certification_Request_Edit, template: SiteRouteUrlTemplates.Certification_Request_Edit, defaults: new { controller = certificationRequest, action = nameof(CertificationRequestController.Edit) });
            routes.MapRoute(name: SiteRouteNames.Certification_Request_Verify, template: SiteRouteUrlTemplates.Certification_Request_Verify, defaults: new { controller = certificationRequest, action = nameof(CertificationRequestController.Verify) });
            routes.MapRoute(name: SiteRouteNames.Certification_Request_Package_Verify, template: SiteRouteUrlTemplates.Certification_Request_Package_Verify, defaults: new { controller = certificationRequest, action = nameof(CertificationRequestController.PackageVerify) });
            routes.MapRoute(name: SiteRouteNames.Certification_Request_View, template: SiteRouteUrlTemplates.Certification_Request_View, defaults: new { controller = certificationRequest, action = nameof(CertificationRequestController.View) });
            routes.MapRoute(name: SiteRouteNames.Certification_Request_Comment_Add, template: SiteRouteUrlTemplates.Certification_Request_Comment_Add, defaults: new { controller = certificationRequest, action = nameof(CertificationRequestController.AddComment) });
            routes.MapRoute(name: SiteRouteNames.Certification_Request_Comment_Delete, template: SiteRouteUrlTemplates.Certification_Request_Comment_Delete, defaults: new { controller = certificationRequest, action = nameof(CertificationRequestController.DeleteComment) });
            routes.MapRoute(name: SiteRouteNames.Certification_Request_Comment_Reply, template: SiteRouteUrlTemplates.Certification_Request_Comment_Reply, defaults: new { controller = certificationRequest, action = nameof(CertificationRequestController.ReplyComment) });
            routes.MapRoute(name: SiteRouteNames.Certification_Request_Notify, template: SiteRouteUrlTemplates.Certification_Request_Notify, defaults: new { controller = certificationRequest, action = nameof(CertificationRequestController.Notify) });
            routes.MapRoute(name: SiteRouteNames.Certification_Request_Email, template: SiteRouteUrlTemplates.Certification_Request_Email, defaults: new { controller = certificationRequest, action = nameof(CertificationRequestController.Email) });
            routes.MapRoute(name: SiteRouteNames.Certification_Request_File_Upload, template: SiteRouteUrlTemplates.Certification_Request_File_Upload, defaults: new { controller = certificationRequest, action = nameof(CertificationRequestController.FileUpload) });

            var manage = nameof(ManageController).Replace("Controller", string.Empty);
            routes.MapRoute(name: SiteRouteNames.Admin, template: SiteRouteUrlTemplates.Admin, defaults: new { controller = manage, action = nameof(ManageController.Dashboard) });
            routes.MapRoute(name: SiteRouteNames.Admin_Portal, template: SiteRouteUrlTemplates.Admin_Portal, defaults: new { controller = manage, action = nameof(ManageController.Dashboard) });
            routes.MapRoute(name: SiteRouteNames.Admin_Certification_Request_All, template: SiteRouteUrlTemplates.Admin_Certification_Request_All, defaults: new { controller = manage, action = nameof(ManageController.AllRequests) });
            routes.MapRoute(name: SiteRouteNames.Admin_Certification_Request_Status_Change, template: SiteRouteUrlTemplates.Admin_Certification_Request_Status_Change, defaults: new { controller = manage, action = nameof(ManageController.ChangeStatus) });
            routes.MapRoute(name: SiteRouteNames.Admin_Superusers, template: SiteRouteUrlTemplates.Admin_Superusers, defaults: new { controller = manage, action = nameof(ManageController.Superusers) });
            routes.MapRoute(name: SiteRouteNames.Admin_Superusers_Grant, template: SiteRouteUrlTemplates.Admin_Superusers_Grant, defaults: new { controller = manage, action = nameof(ManageController.GrantSuperuser) });
            routes.MapRoute(name: SiteRouteNames.Admin_Superusers_Remove, template: SiteRouteUrlTemplates.Admin_Superusers_Remove, defaults: new { controller = manage, action = nameof(ManageController.RemoveSuperuser) });
        }
    }
}