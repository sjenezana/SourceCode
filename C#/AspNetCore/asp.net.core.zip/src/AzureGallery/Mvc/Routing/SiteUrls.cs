﻿namespace AzureGallery.Mvc.Routing
{
    public class SiteUrls
    {
        public const string Home = "/";
        public const string Portal = "/portal";
    }
}