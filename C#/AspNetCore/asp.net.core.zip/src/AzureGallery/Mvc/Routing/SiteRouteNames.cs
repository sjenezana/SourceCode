﻿namespace AzureGallery.Mvc.Routing
{
    public class SiteRouteNames
    {
        public const string Home = nameof(Home);
        public const string Benefits = nameof(Benefits);
        public const string Process = nameof(Process);

        public const string Error = nameof(Error);
        public const string Error_Fire = nameof(Error_Fire);
        public const string Error_Status_Code = nameof(Error_Status_Code);

        public const string SignIn = nameof(SignIn);
        public const string SignOut = nameof(SignOut);

        public const string Portal = nameof(Portal);
        public const string Certification_Request_Mine = nameof(Certification_Request_Mine);
        public const string Certification_Request_Create = nameof(Certification_Request_Create);
        public const string Certification_Request_Submit = nameof(Certification_Request_Submit);
        public const string Certification_Request_Edit = nameof(Certification_Request_Edit);
        public const string Certification_Request_Verify = nameof(Certification_Request_Verify);
        public const string Certification_Request_Package_Verify = nameof(Certification_Request_Package_Verify);
        public const string Certification_Request_View = nameof(Certification_Request_View);
        public const string Certification_Request_Comment_Add = nameof(Certification_Request_Comment_Add);
        public const string Certification_Request_Comment_Delete = nameof(Certification_Request_Comment_Delete);
        public const string Certification_Request_Comment_Reply = nameof(Certification_Request_Comment_Reply);
        public const string Certification_Request_Notify = nameof(Certification_Request_Notify);
        public const string Certification_Request_Email = nameof(Certification_Request_Email);
        public const string Certification_Request_File_Upload = nameof(Certification_Request_File_Upload);

        public const string Admin = nameof(Admin);
        public const string Admin_Portal = nameof(Admin_Portal);
        public const string Admin_Certification_Request_All = nameof(Admin_Certification_Request_All);
        public const string Admin_Certification_Request_Status_Change = nameof(Admin_Certification_Request_Status_Change);
        public const string Admin_Superusers = nameof(Admin_Superusers);
        public const string Admin_Superusers_Grant = nameof(Admin_Superusers_Grant);
        public const string Admin_Superusers_Remove = nameof(Admin_Superusers_Remove);
    }
}