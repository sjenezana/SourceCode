﻿using Microsoft.AspNetCore.Builder;

namespace AzureGallery.Mvc.Security
{
    public static class MicrosoftAccountAuthenticationExtensions
    {
        public static IApplicationBuilder UseMicrosoftAccountAuthentication(
            this IApplicationBuilder app,
            string clientId,
            string clientSecret)
        {
            app.UseCookieAuthentication(new CookieAuthenticationOptions());
            var options = MicrosoftAccountOptionsGenerator.GenerateOptions(
                clientId,
                clientSecret);
            app.UseMicrosoftAccountAuthentication(options);

            return app;
        }
    }
}