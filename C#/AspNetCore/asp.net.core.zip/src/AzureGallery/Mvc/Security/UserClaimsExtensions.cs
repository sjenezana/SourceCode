﻿using AzureGallery.Models;
using System;
using System.Linq;
using System.Security.Claims;

namespace AzureGallery.Mvc.Security
{
    public static class UserClaimsExtensions
    {
        public static bool IsUser(this ClaimsPrincipal user)
        {
            return user.GetUsership() != null;
        }

        public static bool IsAdmin(this ClaimsPrincipal user)
        {
            var usership = user.GetUsership();
            return (usership != null) && usership.IsAdmin;
        }

        public static User GetUsership(this ClaimsPrincipal user)
        {
            return (user.Identity as ClaimsIdentity).GetUsership();
        }

        public static User GetUsership(this ClaimsIdentity identity)
        {
            if (!identity.Claims.Any(c => UserClaimTypes.UserId.Equals(c.Type))) return null;

            return new User
            {
                Id = identity.GetUserId(),
                Nickname = identity.GetName(),
                IsAdmin = identity.IsAdmin(),
                MicrosoftAccount = identity.GetMicrosoftAccount()
            };
        }

        private static Guid GetUserId(this ClaimsIdentity identity)
        {
            return new Guid(identity.Claims.First(c => UserClaimTypes.UserId.Equals(c.Type)).Value);
        }

        private static bool IsAdmin(this ClaimsIdentity identity)
        {
            return "true".Equals(identity.Claims.First(c => UserClaimTypes.IsAdmin.Equals(c.Type)).Value);
        }

        private static string GetMicrosoftAccount(this ClaimsIdentity identity)
        {
            return identity.Claims.First(c => UserClaimTypes.MicrosoftAccount.Equals(c.Type)).Value;
        }
    }
}