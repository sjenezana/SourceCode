﻿using AzureGallery.Models;
using System.Collections.Generic;
using System.Security.Claims;

namespace AzureGallery.Mvc.Security
{
    public class UserClaims
    {
        public static IEnumerable<Claim> GenerateClaims(User user)
        {
            var claims = new List<Claim>();
            if (user == null) return claims;

            claims.Add(new Claim(UserClaimTypes.UserId, user.Id.ToString()));
            claims.Add(new Claim(UserClaimTypes.MicrosoftAccount, user.MicrosoftAccount ?? string.Empty));
            claims.Add(new Claim(UserClaimTypes.IsAdmin, user.IsAdmin.ToString().ToLower()));

            return claims;
        }
    }
}