﻿using System.Linq;
using System.Security.Claims;

namespace AzureGallery.Mvc.Security
{
    public static class IdentityExtensions
    {
        public static string GetName(this ClaimsPrincipal user)
        {
            return (user.Identity as ClaimsIdentity).GetName();
        }

        public static string GetName(this ClaimsIdentity identity)
        {
            return identity.Claims.First(c => ClaimTypes.Name.Equals(c.Type)).Value;
        }

        public static string GetEmailAddress(this ClaimsPrincipal user)
        {
            return (user.Identity as ClaimsIdentity).GetEmailAddress();
        }

        public static string GetEmailAddress(this ClaimsIdentity identity)
        {
            var claim = identity.Claims.FirstOrDefault(c => ClaimTypes.Email.Equals(c.Type));

            return claim == null ? string.Empty : claim.Value;
        }
    }
}