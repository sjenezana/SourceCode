﻿using AzureGallery.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OAuth;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Security.Claims;
using System.Threading.Tasks;

namespace AzureGallery.Mvc.Security
{
    public class MicrosoftAccountOptionsGenerator
    {
        public static MicrosoftAccountOptions GenerateOptions(string clientId, string clientSecret)
        {
            var options = new MicrosoftAccountOptions
            {
                ClientId = clientId,
                ClientSecret = clientSecret,
                SignInScheme = CookieAuthenticationDefaults.AuthenticationScheme,
                AutomaticChallenge = true,
                Events = new OAuthEvents
                {
                    OnRemoteFailure = RemoteFailure,
                    OnCreatingTicket = CreatingTicket
                }
            };

            return options;
        }

        private static async Task CreatingTicket(OAuthCreatingTicketContext context)
        {
            var userIdentity = context.Ticket.Principal.Identity as ClaimsIdentity;
            if (userIdentity != null)
            {
                var userService = context.HttpContext.RequestServices.GetService<IUserService>();
                if (userService == null)
                {
                    throw new Exception("Unable to load an instance of IUserService.");
                }

                // the email address which is identified as Microsoft Account or Azure Ad account.
                var email = userIdentity.GetEmailAddress();
                if (string.IsNullOrEmpty(email))
                {
                    throw new Exception("Unable to get the email address of this account.");
                }

                var user = await userService.GetUserByMicrosoftAccountAsync(email);
                if (user == null)
                {
                    // when an user visits this web site for the first time,
                    // we create an User for him, with his/her email and name.
                    user = await userService.CreateUserAsync(email, userIdentity.GetName());
                }

                userIdentity.AddClaims(UserClaims.GenerateClaims(user));
            }
        }

        // Handle sign-in errors differently than generic errors.
        private static Task RemoteFailure(FailureContext context)
        {
            context.HandleResponse();
            context.Response.Redirect("/error?message=" + context.Failure.Message);

            return Task.CompletedTask;
        }
    }
}