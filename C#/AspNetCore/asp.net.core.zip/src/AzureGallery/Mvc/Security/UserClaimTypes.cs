﻿namespace AzureGallery.Mvc.Security
{
    public static class UserClaimTypes
    {
        public const string UserId = "microsoft.azure.gallery.user.id";
        public const string MicrosoftAccount = "microsoft.azure.gallery.user.msa";
        public const string IsAdmin = "microsoft.azure.gallery.user.isadmin";
    }
}