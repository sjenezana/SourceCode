﻿using AzureGallery.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace AzureGallery.Mvc.ViewModels
{
    public class CertificationRequestCreateViewModel
    {
        public CertificationRequest CertificationRequest { get; set; } = new CertificationRequest();

        [Required(ErrorMessage = "The Framework is required.")]
        [Single("Only one framework can be choosen.")]
        public IList<string> FrameworkIds { get; set; }

        [Required(ErrorMessage = "The Dependency is required.")]
        [Single("Only one dependency can be choosen.")]
        public IList<string> DatabaseIds { get; set; }
    }
}