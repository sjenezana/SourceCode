﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace AzureGallery.Mvc
{
    public class MsResourceAttribute : ValidationAttribute, IClientModelValidator
    {
        private string _hasMsResourcePorperty;

        public MsResourceAttribute(string hasMsResourcePorperty, string errorMessage) : base()
        {
            _hasMsResourcePorperty = hasMsResourcePorperty;
            ErrorMessage = errorMessage;
        }
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var propertyInfo = validationContext.ObjectType.GetProperty(_hasMsResourcePorperty);
            var hasMsResource = (bool)propertyInfo.GetValue(validationContext.ObjectInstance, null);
            if (hasMsResource && string.IsNullOrWhiteSpace((string)value))
            {
                return new ValidationResult(ErrorMessage);
            }
            else
            {
                return ValidationResult.Success;
            }
        }

        public void AddValidation(ClientModelValidationContext context)
        {
            MergeAttribute(context.Attributes, "data-val", "true");
            MergeAttribute(context.Attributes, "data-val-msresource", ErrorMessage);
        }

        private void MergeAttribute(IDictionary<string, string> attributes, string key, string value)
        {
            if (attributes.ContainsKey(key))
            {
                return;
            }
            attributes.Add(key, value);
        }
    }


    public class SingleAttribute : ValidationAttribute
    {
        public SingleAttribute(string errorMessage) : base()
        {
            ErrorMessage = errorMessage;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            return ((IList<string>)value).Count > 1 ? new ValidationResult(ErrorMessage) : ValidationResult.Success;
        }
    }
}