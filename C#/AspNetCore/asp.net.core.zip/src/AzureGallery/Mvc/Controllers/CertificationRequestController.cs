using AzureGallery.Mvc.Routing;
using AzureGallery.Mvc.Security;
using AzureGallery.Mvc.ViewModels;
using AzureGallery.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading.Tasks;
using AzureGallery.Utilities;
using System.Diagnostics;

namespace AzureGallery.Mvc.Controllers
{
    public class CertificationRequestController : Controller
    {
        private readonly ILogger _logger;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ICertificationRequestService _certificationRequestService;
        private IMetadataService _metadataService;
        private IAureStorageService _azureStorageService;
        private IEmailService _emailService;

        public CertificationRequestController(ILoggerFactory loggerFactory,
            IHostingEnvironment hostingEnvironment,
            ICertificationRequestService certificationRequestService,
            IMetadataService metadataService,
            IAureStorageService azureStorageService,
            IEmailService emailService)
        {
            _logger = loggerFactory.CreateLogger<CertificationRequestController>();
            _hostingEnvironment = hostingEnvironment;
            _certificationRequestService = certificationRequestService;
            _metadataService = metadataService;
            _azureStorageService = azureStorageService;
            _emailService = emailService;
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Create()
        {
            var model = new CertificationRequestCreateViewModel();

            await LoadViewDataForRequestAsync();
            ViewBag.IsCreate = true;

            return View("submit", model);
        }

        [Authorize]
        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public async Task<IActionResult> Create(CertificationRequestCreateViewModel model)
        {
            if (!ModelState.IsValid || model.CertificationRequest.Id == null)
            {
                await LoadViewDataForRequestAsync();
                return View("Submit", model);
            }

            string Id = model.CertificationRequest.Id.ToString();
            TempData.Put(Id, model);

            return RedirectToRoute(SiteRouteNames.Certification_Request_Submit, new { id = Id });
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Submit(string id)
        {
            if (id == null || id.Trim().Length == 0)
                return RedirectToRoute(SiteRouteNames.Portal);

            CertificationRequestCreateViewModel model = TempData.Get<CertificationRequestCreateViewModel>(id);
            if (model == null)
                return RedirectToRoute(SiteRouteNames.Portal);

            await _certificationRequestService.CreateCertificationRequestAsync(User.GetEmailAddress(),
                model.CertificationRequest, model.DatabaseIds, model.FrameworkIds);

            return RedirectToRoute(SiteRouteNames.Certification_Request_Verify, new { id = model.CertificationRequest.Id });
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Edit(Guid id)
        {
            if (!await _certificationRequestService.HasOwnerShip(User.GetEmailAddress(), id) && !User.IsAdmin())
            {
                return RedirectToRoute(SiteRouteNames.Portal);
            }

            var certificationRequest = await _certificationRequestService.GetCertificationRequestById(id);

            if (certificationRequest == null)
            {
                return View("ResourceNotFound");
            }

            var model = new CertificationRequestCreateViewModel
            {
                CertificationRequest = certificationRequest
            };

            model.DatabaseIds = model.CertificationRequest.AppDatabases.Select(a => a.DatabaseId.ToString()).ToList();
            model.FrameworkIds = model.CertificationRequest.AppFrameworks.Select(a => a.FrameworkId.ToString()).ToList();

            await LoadViewDataForRequestAsync();
            ViewBag.IsCreate = false;

            return View("Submit", model);
        }

        [Authorize]
        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public async Task<IActionResult> Edit(CertificationRequestCreateViewModel model)
        {
            if (!await _certificationRequestService.HasOwnerShip(User.GetEmailAddress(), model.CertificationRequest.Id) && !User.IsAdmin())
            {
                return RedirectToRoute(SiteRouteNames.Portal);
            }

            if (!ModelState.IsValid)
            {
                await LoadViewDataForRequestAsync();
                return View("Submit", model);
            }

            await _certificationRequestService.UpdateCertificationRequestAsync(model.CertificationRequest, model.DatabaseIds, model.FrameworkIds);

            return RedirectToRoute(SiteRouteNames.Certification_Request_Verify, new { id = model.CertificationRequest.Id });
        }

        private async Task LoadViewDataForRequestAsync()
        {
            ViewBag.Frameworks = (await _metadataService.GetAllFrameworksAsync()).Select(f => new SelectListItem() { Text = f.Name, Value = f.Id.ToString() });
            ViewBag.Databases = (await _metadataService.GetAllDatabasesAsync()).Select(d => new SelectListItem() { Text = d.Name, Value = d.Id.ToString() });
            ViewBag.CertificationKinds = (await _metadataService.GetAllCertificationkindsAsync()).Select(c => new SelectListItem() { Text = c.Name, Value = c.Id.ToString() });
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> FileUpload()
        {
            var file = Request.Form.Files[0];
            var result = file.Name.Contains("package") ? await _azureStorageService.TryUploadPackageAsync(file) : await _azureStorageService.TryUploadTestResultAsync(file);

            return Json(new
            {
                SuccessOrNot = !string.IsNullOrEmpty(result),
                Url = result
            });
        }

        [Authorize]
        [HttpGet]
        public IActionResult Portal()
        {
            return View("Mine");
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> GetMyRequests(int draw, int start, int length)
        {
            var count = 0;
            var requests = await _certificationRequestService.GetCertificationRequestsByUser(User.GetEmailAddress(), start, length, Request.Query["search[value]"].ToString(), int.Parse(Request.Query["order[0][column]"]), Request.Query["order[0][dir]"].ToString(), out count);
            return Json(new
            {
                draw = draw,
                recordsTotal = count,
                recordsFiltered = count,
                data = requests.Select(c => new { companyName = c.CompanyName, appName = c.AppName, updated = c.UpdatedTime.ToString(), status = c.CertificationRequestState.Name, id = c.Id.ToString() })
            });
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Verify(Guid id)
        {
            var model = await _certificationRequestService.GetCertificationRequestById(id);

            return View(model);
        }

        [Authorize]
        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public IActionResult Notify(Guid id)
        {
            string EmailCheck = string.Format("EmailCheck_{0}", id.ToString());
            TempData.Put(EmailCheck, EmailCheck);
            return RedirectToRoute(SiteRouteNames.Certification_Request_Email, id);
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Email(Guid id)
        {
            if (id == null || id.ToString().Trim().Length == 0)
                return RedirectToRoute(SiteRouteNames.Portal);

            string EmailCheck = string.Format("EmailCheck_{0}", id.ToString());
            if (TempData[EmailCheck] == null)
                return RedirectToRoute(SiteRouteNames.Portal);

            var request = await _certificationRequestService.GetCertificationRequestById(id);
            if (request != null)
                await _emailService.SendMessageForRequestCreatedAsync(request);

            return RedirectToRoute(SiteRouteNames.Portal);
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> PackageVerify(string packageUrl, Guid id)
        {
            var packageValidation = await _certificationRequestService.PackageVerifyAsync(packageUrl, _hostingEnvironment.ContentRootPath);
            await _certificationRequestService.ChangeStatusAsync(id, packageValidation.Result ? "Validating Passed" : "Validating Failed");
            return Json(new
            {
                PackageValidation = packageValidation
            });
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> View(Guid id)
        {
            if (!User.IsAdmin() && !await _certificationRequestService.HasOwnerShip(User.GetEmailAddress(), id))
            {
                return RedirectToRoute(SiteRouteNames.Portal);
            }

            var model = await _certificationRequestService.GetCertificationRequestAndCommentsByIdAsync(id);

            if (model == null)
            {
                return View("ResourceNotFound");
            }

            return View("Detail", model);
        }

        [Authorize]
        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public async Task<IActionResult> AddComment(Guid id, string content)
        {
            if (User.IsAdmin())
            {
                await _certificationRequestService.AddCommentAsync(id, content, User.GetEmailAddress(), Request.Host.ToString());
            }

            return RedirectToRoute(SiteRouteNames.Certification_Request_View, new { id = id });
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> DeleteComment(Guid id)
        {
            // When the comment is nonexistent (may already delete by other people),
            // we also make it can show "deleted sucessfully" on page because we cannot check the ownership on an nonexistent comment
            if ((await _certificationRequestService.GetCommentByIdAsync(id)) == null)
                return Json(new { success = true });

            if (User.IsAdmin() || await _certificationRequestService.HasAuthorShip(User.GetEmailAddress(), id))
            {
                await _certificationRequestService.DeleteCommentAsync(id);

                return Json(new { success = true });
            }

            return Json(new { success = false });
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> ReplyComment(Guid id, string content)
        {
            var reply = await _certificationRequestService.ReplyCommentAsync(id, content, User.GetEmailAddress(), Request.Host.ToString());
            if (reply != null)
            {
                return Json(new
                {
                    success = true,
                    replyId = reply.Id.ToString(),
                    time = reply.UpdatedTime.ToString()
                });
            }

            return Json(new { success = false });
        }
    }
}