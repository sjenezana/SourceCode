﻿using AzureGallery.Mvc.Security;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;

namespace AzureGallery.Mvc.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger _logger;

        public HomeController(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<HomeController>();
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Error(string message)
        {
            var exception = string.IsNullOrEmpty(message) ? HttpContext.Features.Get<IExceptionHandlerFeature>()?.Error : new Exception(message);

            if (User.Identity.IsAuthenticated)
            {
                _logger.LogError("Eorror: {0}: User Account: {1} User Name: {2} Exception: {3}", DateTime.Now, User.GetEmailAddress(), User.GetName(), exception);
            }
            else
            {
                _logger.LogError("Error: {0}: Exception {1}", DateTime.Now, exception);
            }

            if (exception != null)
            {
                ViewBag.Error = exception.Message;
            }

            return View();
        }

        public IActionResult HandleStatusCode(int statusCode)
        {
            if (statusCode == 404)
            {
                return View("ResourceNotFound");
            }
            else
            {
                ViewBag.Error = $"Status: {statusCode}";

                return View("Error");
            }
        }

        public IActionResult Fire()
        {
            throw new Exception("Testing custom errors ... you can ignore this.");
        }

        public IActionResult Benefits()
        {
            return View();
        }

        public IActionResult Process()
        {
            return View();
        }
    }
}