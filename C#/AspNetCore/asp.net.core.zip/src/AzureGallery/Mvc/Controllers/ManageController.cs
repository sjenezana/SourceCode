﻿using AzureGallery.Mvc.Routing;
using AzureGallery.Mvc.Security;
using AzureGallery.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace AzureGallery.Mvc.Controllers
{
    public class ManageController : Controller
    {
        private ICertificationRequestService _certificationRequestService;
        private IUserService _userService;

        public ManageController(ICertificationRequestService certificationRequestService, IUserService userService)
        {
            _certificationRequestService = certificationRequestService;
            _userService = userService;
        }

        [Authorize]
        [HttpGet]
        public IActionResult Dashboard()
        {
            if (!User.IsAdmin()) return RedirectToRoute(SiteRouteNames.Portal);

            return View();
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> AllRequests(int draw, int start, int length)
        {
            if (!User.IsAdmin()) return RedirectToRoute(SiteRouteNames.Portal);

            var count = 0;
            var requests = await _certificationRequestService.GetCertificationRequests(start, length, Request.Query["search[value]"].ToString(), int.Parse(Request.Query["order[0][column]"]), Request.Query["order[0][dir]"].ToString(), out count);
            return Json(new
            {
                draw = draw,
                recordsTotal = count,
                recordsFiltered = count,
                data = requests.Select(c => new { companyName = c.CompanyName, appName = c.AppName, updated = c.UpdatedTime.ToString(), status = c.CertificationRequestState.Name, id = c.Id.ToString() })
            });
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> ChangeStatus(Guid id, string status)
        {
            if (!User.IsAdmin()) return Json(new { isSucceed = false });

            await _certificationRequestService.ChangeStatusAsync(id, status);

            return Json(new { isSucceed = true });
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Superusers()
        {
            if (!User.IsAdmin())
            {
                return RedirectToRoute(SiteRouteNames.Portal);
            }

            return View(await _userService.GetSuperusersAsync());
        }

        [Authorize]
        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public async Task<IActionResult> GrantSuperuser(string nickname, string microsoftAccount)
        {
            if (!User.IsAdmin())
            {
                return RedirectToRoute(SiteRouteNames.Portal);
            }

            await _userService.GrantSuperuserAsync(nickname, microsoftAccount);

            return RedirectToRoute(SiteRouteNames.Admin_Superusers);
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> RemoveSuperuser(string microsoftAccount)
        {
            if (!User.IsAdmin())
            {
                return Json(new { success = false });
            }

            await _userService.RemoveSuperuserAsync(microsoftAccount);

            return Json(new { success = true });
        }
    }
}