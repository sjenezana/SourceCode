﻿using AzureGallery.Mvc.Routing;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace AzureGallery.Mvc.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        private readonly ILogger _logger;

        public AccountController(
            ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<AccountController>();
        }

        [AllowAnonymous]
        public async Task SignIn(string returnUrl = null)
        {
            if (!User.Identity.IsAuthenticated)
            {
                await HttpContext.Authentication.ChallengeAsync(new AuthenticationProperties { RedirectUri = returnUrl ?? SiteUrls.Portal });
            }
        }

        public async Task SignOut()
        {
            if (User.Identity.IsAuthenticated)
            {
                await HttpContext.Authentication.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
                Response.Redirect(SiteUrls.Home);
            }
        }
    }
}