﻿using AzureGallery.Models;
using AzureGallery.Utilities;
using Microsoft.Extensions.Options;
using System;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace AzureGallery.Services
{
    public class EmailService : IEmailService
    {
        private readonly IOptions<SendGridOptions> _sendGridOptions;

        public EmailService(IOptions<SendGridOptions> sendGridOptions)
        {
            _sendGridOptions = sendGridOptions;
        }

        public Task SendMessageForRequestCreatedAsync(CertificationRequest request)
        {
            SendMessageForRequest("CREATED", request);

            return Task.CompletedTask;
        }

        private void SendMessageForRequest(string action, CertificationRequest request)
        {
            request.CertificationKind.Name = WebUtility.HtmlEncode(request.CertificationKind.Name);
            request.CompanyName = WebUtility.HtmlEncode(request.CompanyName);
            request.CompanyDescription = WebUtility.HtmlEncode(request.CompanyDescription);
            request.CompanyUrl = WebUtility.HtmlEncode(request.CompanyUrl);
            request.AppDescription = WebUtility.HtmlEncode(request.AppDescription);
            request.MicrosoftResourceEmail = WebUtility.HtmlEncode(request.MicrosoftResourceEmail);
            request.PackageUrl = WebUtility.HtmlEncode(request.PackageUrl);
            request.TestResultUrl = WebUtility.HtmlEncode(request.TestResultUrl);

            var subject = BuilSubject(request, action);
            var body = BuildBody(request, action);

            SendGridEmailHelper.SendAsync(_sendGridOptions.Value.ApiKey, subject, BuildHtmlStyles() + body, _sendGridOptions.Value.From, _sendGridOptions.Value.FromName, _sendGridOptions.Value.To, $"{request.ContactEmail},{_sendGridOptions.Value.Cc}");
        }

        private string BuildBody(CertificationRequest request, string action)
        {
            var body = new StringBuilder();
            body.Append($"CERTIFICATION REQUEST {action}: {request.AppName}<br /><br /><br />");

            body.Append("<table><caption>Company Information</caption>");
            body.Append($"<tr><td class='name'>Company Name</td><td>{request.CompanyName}</td></tr>");
            body.Append($"<tr><td class='name'>Description</td><td>{request.CompanyDescription}</td></tr>");
            body.Append($"<tr><td class='name'>URL</td><td>{request.CompanyUrl}</td></tr>");
            body.Append($"</table>");

            body.Append("<table><caption>Contact Information</caption>");
            body.Append($"<tr><td class='name'>Contact Name</td><td>{request.ContactName}</td></tr>");
            body.Append($"<tr><td class='name'>Email</td><td>{request.ContactEmail}</td></tr>");
            body.Append($"<tr><td class='name'>Role</td><td>{request.ContactRole}</td></tr>");
            body.Append($"</table>");

            body.Append("<table><caption>Application Details</caption>");
            body.Append($"<tr><td class='name'>Name</td><td>{request.AppName}</td></tr>");
            body.Append($"<tr><td class='name'>Dependencies</td><td>{string.Join(", ", request.AppDatabases.Select(a => a.Database.Name))}</td></tr>");
            body.Append($"<tr><td class='name'>Frameworks</td><td>{string.Join(", ", request.AppFrameworks.Select(a => a.Framework.Name))}</td></tr>");
            body.Append($"<tr><td class='name'>Description</td><td>{request.AppDescription}</td></tr>");
            body.Append($"<tr><td class='name'>Zip Package</td><td>{request.PackageUrl}</td></tr>");
            body.Append($"<tr><td class='name'>Test Result</td><td>{request.TestResultUrl}</td></tr>");
            body.Append($"</table>");

            body.Append("<table><caption>Contacted Microsoft Resource</caption>");
            body.Append($"<tr><td class='name'>Name</td><td>{request.MicrosoftResourceName}</td></tr>");
            body.Append($"<tr><td class='name'>Email</td><td>{request.MicrosoftResourceEmail}</td></tr>");
            body.Append($"</table>");

            body.Append("<table><caption>Certification Kind</caption>");
            body.Append($"<tr><td class='name'>Name</td><td>{request.CertificationKind.Name}</td></tr>");
            body.Append($"<tr><td class='name'>Scenario</td><td>{request.CertificationScenario}</td></tr>");
            body.Append($"</table>");

            body.Append("<hr /><br /><br />");

            return body.ToString();
        }

        private string BuilSubject(CertificationRequest request, string action)
        {
            return $"CERTIFICATION REQUEST {action}: {request.CompanyName} {request.AppName}";
        }

        private static string BuildHtmlStyles()
        {
            return @"
<style>
body
{
    font-family: Segoe UI, Verdana, Tahoma, Helvetica, Arial, sans-serif;
    font-size: 12px;
    line-height: 1.2em;
}
table
{
    margin: 10px 0 !important;
    padding: 0 !important;
}
table caption
{
    text-align: left;
    font-weight: bold;
    color: White;
    background-color: #555555;
    padding: 2px 10px 2px 0 !important;
    margin: 0 !important;
}
table tr
{
    margin: 0;
    padding: 0;
}
table tr td
{
    padding: 2px 25px 2px 10px;
    margin: 0;
    border-bottom: solid 1px #666666;
    font-family: Segoe UI, Verdana, Tahoma, Helvetica, Arial, sans-serif;
    font-size: 12px;
    line-height: 1.2em;
}
table tr td.name
{
    width: 200px;
    text-align: right;
    font-weight: bold;
    vertical-align: top;
    color: White;
    background-color: #888888;
}
</style>
";
        }

        public Task SendMessageForAddCommentAsync(Guid id, string appName, string author, string email, string content, DateTime now, string hostName)
        {
            var body = $"{author} added a comment on the Certification request: <a href='https://{hostName}/certrequests/{id}'>{appName}</a> <br /><br />"
                     + $"{content} -- {now.ToString()}<br /><br /><br /><br /> -- <a href='https://{hostName}/'>Azure App Service Certification</a>";
            SendGridEmailHelper.SendAsync(_sendGridOptions.Value.ApiKey, $"Comment Added: {appName}", body, _sendGridOptions.Value.From, _sendGridOptions.Value.FromName, email, _sendGridOptions.Value.From);

            return Task.CompletedTask;
        }

        public Task SendMessageForReplyCommentAsync(Guid id, string appName, string author, string email, string content, DateTime now, string hostName)
        {
            var body = $"{author} replied on the Certification request: <a href='https://{hostName}/certrequests/{id}'>{appName}</a> <br /><br />"
                    + $"{content} -- {now.ToString()}<br /><br /><br /><br /> -- <a href='https://{hostName}/'>Azure App Service Certification</a>";
            SendGridEmailHelper.SendAsync(_sendGridOptions.Value.ApiKey, $"Comment Replied: {appName}", body, _sendGridOptions.Value.From, _sendGridOptions.Value.FromName, email, _sendGridOptions.Value.From);

            return Task.CompletedTask;
        }
    }
}