﻿using AzureGallery.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AzureGallery.Services
{
    public interface IMetadataService
    {
        Task<IList<Framework>> GetAllFrameworksAsync();

        Task<IList<Database>> GetAllDatabasesAsync();

        Task<IList<CertificationKind>> GetAllCertificationkindsAsync();

        Task<CertificationRequestState> GetCertificatedRequestStateByNameAsync(string name);
    }
}