﻿using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace AzureGallery.Services
{
    public interface IAureStorageService
    {
        Task<string> TryUploadPackageAsync(IFormFile package);

        Task<string> TryUploadTestResultAsync(IFormFile testResult);
    }
}