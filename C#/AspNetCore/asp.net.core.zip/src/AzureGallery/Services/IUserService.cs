﻿using AzureGallery.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AzureGallery.Services
{
    public interface IUserService
    {
        Task<User> GetUserByMicrosoftAccountAsync(string microsoftAccount);

        Task<User> CreateUserAsync(string microsoftAccount, string nickname);

        Task<List<User>> GetSuperusersAsync();

        Task GrantSuperuserAsync(string nickname, string microsoftAccount);

        Task RemoveSuperuserAsync(string microsoftAccount);
    }
}