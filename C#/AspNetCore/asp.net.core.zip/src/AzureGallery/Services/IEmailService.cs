﻿using AzureGallery.Models;
using System.Threading.Tasks;
using System;

namespace AzureGallery.Services
{
    public interface IEmailService
    {
        Task SendMessageForRequestCreatedAsync(CertificationRequest request);

        Task SendMessageForAddCommentAsync(Guid id, string appName, string author, string email, string content, DateTime now, string hostName);

        Task SendMessageForReplyCommentAsync(Guid id, string appName, string author, string email, string content, DateTime now, string hostName);
    }
}
