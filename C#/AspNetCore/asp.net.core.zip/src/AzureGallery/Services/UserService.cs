﻿using AzureGallery.Data;
using AzureGallery.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AzureGallery.Services
{
    public class UserService : IUserService
    {
        private AzureGalleryDbContext _db;

        public UserService(AzureGalleryDbContext context)
        {
            _db = context;
        }

        public Task<User> GetUserByMicrosoftAccountAsync(string microsoftAccount)
        {
            return Task.FromResult(_db.Users.FirstOrDefault(u => u.MicrosoftAccount.Equals(microsoftAccount, StringComparison.OrdinalIgnoreCase)));
        }

        public async Task<User> CreateUserAsync(string microsoftAccount, string nickname)
        {
            var now = DateTime.Now;
            var user = new User
            {
                Id = Guid.NewGuid(),
                MicrosoftAccount = microsoftAccount,
                Nickname = nickname,
                EmailAddress = microsoftAccount,
                CreatedTime = now,
                UpdatedTime = now,
                IsAdmin = false
            };

            _db.Users.Add(user);
            await _db.SaveChangesAsync();

            return user;
        }

        public Task<List<User>> GetSuperusersAsync()
        {
            return _db.Users.Where(u => u.IsAdmin).ToListAsync();
        }

        public async Task GrantSuperuserAsync(string nickname, string microsoftAccount)
        {
            var admin = await _db.Users.FirstOrDefaultAsync(u => u.MicrosoftAccount.Equals(microsoftAccount, StringComparison.OrdinalIgnoreCase));

            if (admin != null)
            {
                admin.IsAdmin = true;
            }
            else
            {
                var now = DateTime.Now;
                _db.Users.Add(new User
                {
                    Id = Guid.NewGuid(),
                    Nickname = nickname,
                    MicrosoftAccount = microsoftAccount,
                    EmailAddress = microsoftAccount,
                    IsAdmin = true,
                    CreatedTime = now,
                    UpdatedTime = now
                });
            }

            await _db.SaveChangesAsync();
        }

        public async Task RemoveSuperuserAsync(string microsoftAccount)
        {
            var admin = await _db.Users.FirstOrDefaultAsync(u => u.MicrosoftAccount.Equals(microsoftAccount, StringComparison.OrdinalIgnoreCase));
            if (admin != null)
            {
                admin.IsAdmin = false;
                await _db.SaveChangesAsync();
            }
        }
    }
}