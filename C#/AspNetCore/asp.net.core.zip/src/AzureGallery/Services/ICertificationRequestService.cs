﻿using AzureGallery.Models;
using AzureGallery.PackageVerify;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AzureGallery.Services
{
    public interface ICertificationRequestService
    {
        Task CreateCertificationRequestAsync(string microsoftAccount, CertificationRequest certificationRequest, IList<string> databaseIds, IList<string> frameworkIds);

        Task<bool> HasOwnerShip(string microsoftAccount, Guid id);

        Task<CertificationRequest> GetCertificationRequestById(Guid id);

        Task UpdateCertificationRequestAsync(CertificationRequest certificationRequest, IList<string> databaseIds, IList<string> frameworkIds);

        Task<PackageValidationResult> PackageVerifyAsync(string packageUrl, string contentRootPath);

        Task ChangeStatusAsync(Guid id, string status);

        Task<IList<CertificationRequest>> GetCertificationRequests(int start, int length, string keyword, int orderIndex, string direction, out int count);

        Task<IList<CertificationRequest>> GetCertificationRequestsByUser(string microsoftAccount, int start, int length, string keyword, int orderIndex, string orderDir, out int count);

        Task<CertificationRequest> GetCertificationRequestAndCommentsByIdAsync(Guid id);

        Task AddCommentAsync(Guid id, string content, string MicrosoftAccount, string hostName);

        Task DeleteCommentAsync(Guid commentId);

        Task<bool> HasAuthorShip(string microsoftAccount, Guid id);

        Task<Comment> ReplyCommentAsync(Guid id, string content, string microsoftAccount, string hostName);

        Task<Comment> GetCommentByIdAsync(Guid id);
    }
}