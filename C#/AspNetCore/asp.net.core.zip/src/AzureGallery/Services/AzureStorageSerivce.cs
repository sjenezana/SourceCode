﻿using AzureGallery.Utilities;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Threading.Tasks;

namespace AzureGallery.Services
{
    public class AzureStorageSerivce : IAureStorageService
    {
        private readonly IOptions<AzureStorageOptions> _azureStorageOptions;
        private readonly ILogger _logger;

        public AzureStorageSerivce(IOptions<AzureStorageOptions> azureStorageOptions, ILoggerFactory loggerFactory)
        {
            _azureStorageOptions = azureStorageOptions;
            _logger = loggerFactory.CreateLogger<AzureStorageSerivce>();
        }

        public async Task<string> TryUploadPackageAsync(IFormFile package)
        {
            try
            {
                return await AzureStorageHelper.Upload(_azureStorageOptions.Value.ConnectionString, _azureStorageOptions.Value.PackagesContainer, package.Name, package);
            }
            catch (Exception e)
            {
                _logger.LogError("Upload package failed: {0}: {1}", DateTime.Now, e);
                return string.Empty;
            }
        }

        public async Task<string> TryUploadTestResultAsync(IFormFile testResult)
        {
            try
            {
                return await AzureStorageHelper.Upload(_azureStorageOptions.Value.ConnectionString, _azureStorageOptions.Value.TestResultsContainer, testResult.Name, testResult);
            }
            catch (Exception e)
            {
                _logger.LogError("Upload test result failed : {0}: {1}", DateTime.Now, e);
                return string.Empty;
            }
        }
    }
}