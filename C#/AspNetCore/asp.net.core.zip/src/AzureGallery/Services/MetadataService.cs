﻿using AzureGallery.Data;
using AzureGallery.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System;

namespace AzureGallery.Services
{
    public class MetadataService : IMetadataService
    {
        private AzureGalleryDbContext _context;

        public MetadataService(AzureGalleryDbContext context)
        {
            _context = context;
        }

        public Task<IList<Framework>> GetAllFrameworksAsync()
        {
            return Task.FromResult<IList<Framework>>(_context.Frameworks.OrderBy(f => f.DisplayOrder).ToList());
        }

        public Task<IList<Database>> GetAllDatabasesAsync()
        {
            return Task.FromResult<IList<Database>>(_context.Databases.OrderBy(d => d.DisplayOrder).ToList());
        }

        public Task<IList<CertificationKind>> GetAllCertificationkindsAsync()
        {
            return Task.FromResult<IList<CertificationKind>>(_context.CertificationKinds.OrderBy(c => c.DisplayOrder).ToList());
        }

        public Task<CertificationRequestState> GetCertificatedRequestStateByNameAsync(string name)
        {
            return Task.FromResult(_context.CertificationRequestStates.FirstOrDefault(c => c.Name.Equals(name, StringComparison.OrdinalIgnoreCase)));
        }
    }
}