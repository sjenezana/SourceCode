﻿using AzureGallery.Data;
using AzureGallery.Models;
using AzureGallery.PackageVerify;
using AzureGallery.Utilities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace AzureGallery.Services
{
    public class CeritificationRequestService : ICertificationRequestService
    {
        private AzureGalleryDbContext _context;
        private IEmailService _emailService;
        private readonly ILogger _logger;

        public CeritificationRequestService(AzureGalleryDbContext context, IEmailService emailService, ILoggerFactory loggerFactory)
        {
            _context = context;
            _emailService = emailService;
            _logger = loggerFactory.CreateLogger<ICertificationRequestService>();
        }

        public async Task CreateCertificationRequestAsync(string microsoftAccount, CertificationRequest certificationRequest, IList<string> databaseIds, IList<string> frameworkIds)
        {
            var now = DateTime.Now;
            certificationRequest.CreatedTime = now;
            certificationRequest.UpdatedTime = now;
            certificationRequest.CertificationRequestState = _context.CertificationRequestStates.First(c => c.Name.Equals("Validating"));
            certificationRequest.Owner = _context.Users.First(u => u.MicrosoftAccount.Equals(microsoftAccount, StringComparison.OrdinalIgnoreCase));
            certificationRequest.AppDatabases = databaseIds.Select(d => new AppDatabase { CertificationRequestId = certificationRequest.Id, DatabaseId = new Guid(d) }).ToList();
            certificationRequest.AppFrameworks = frameworkIds.Select(f => new AppFramework { CertificationRequestId = certificationRequest.Id, FrameworkId = new Guid(f) }).ToList();
            _context.CertificationRequests.Add(certificationRequest);

            await _context.SaveChangesAsync();
        }

        public Task<bool> HasOwnerShip(string microsoftAccount, Guid id)
        {
            return Task.FromResult(_context.CertificationRequests.Any(c => c.Id.Equals(id) && c.Owner.MicrosoftAccount.Equals(microsoftAccount, StringComparison.OrdinalIgnoreCase)));
        }

        public Task<CertificationRequest> GetCertificationRequestById(Guid id)
        {
            return _context.CertificationRequests
                 .Include(c => c.AppFrameworks).ThenInclude(a => a.Framework)
                 .Include(c => c.AppDatabases).ThenInclude(a => a.Database)
                 .Include(c => c.CertificationKind)
                 .AsNoTracking()
                 .FirstOrDefaultAsync(c => c.Id.Equals(id));
        }

        public async Task UpdateCertificationRequestAsync(CertificationRequest certificationRequest, IList<string> databaseIds, IList<string> frameworkIds)
        {
            var appDatabasesToDelete = _context.AppDatabases.Where(a => a.CertificationRequestId.Equals(certificationRequest.Id));
            var appFrameworksToDelete = _context.AppFrameworks.Where(a => a.CertificationRequestId.Equals(certificationRequest.Id));
            _context.AppDatabases.RemoveRange(appDatabasesToDelete);
            _context.AppFrameworks.RemoveRange(appFrameworksToDelete);

            await _context.SaveChangesAsync();

            var newAppDatabases = databaseIds.Select(d => new AppDatabase { CertificationRequestId = certificationRequest.Id, DatabaseId = new Guid(d) }).ToList();
            var newAppFrameworks = frameworkIds.Select(f => new AppFramework { CertificationRequestId = certificationRequest.Id, FrameworkId = new Guid(f) }).ToList();
            _context.AppDatabases.AddRange(newAppDatabases);
            _context.AppFrameworks.AddRange(newAppFrameworks);

            certificationRequest.CertificationRequestState = _context.CertificationRequestStates.First(c => c.Name.Equals("Validating"));
            certificationRequest.UpdatedTime = DateTime.Now;

            _context.CertificationRequests.Update(certificationRequest);

            await _context.SaveChangesAsync();
        }

        public async Task ChangeStatusAsync(Guid id, string status)
        {
            var certificationRequest = _context.CertificationRequests.First(c => c.Id.Equals(id));
            certificationRequest.CertificationRequestState = _context.CertificationRequestStates.First(c => c.Name.Equals(status));

            await _context.SaveChangesAsync();
        }

        public async Task<PackageValidationResult> PackageVerifyAsync(string packageUrl, string contentRootPath)
        {
            if (string.IsNullOrWhiteSpace(packageUrl))
            {
                return PackageValidationResult.Fail("The Package URL is empty");
            }

            // This make the downloaded zip file name can not be duplicated in local directory.
            var packageFileName = Guid.NewGuid().ToString() + "package.zip";

            var tempPackagePath = Path.Combine(contentRootPath, $@"Temp_Packages\{packageFileName}");

            var package = await StreamHelper.DownloadFrom(packageUrl, tempPackagePath);
            if (package == null)
            {
                return PackageValidationResult.Fail("The Package can't be download for validating.");
            }

            var validationResult = (new PackageValidator()).Validate(package);
            // try to delete the package zip file
            try { package.Delete(); }
            catch (Exception e)
            {
                _logger.LogError("Delete package failed: {0}: {1}", DateTime.Now, e);
            }

            return validationResult;
        }

        public Task<IList<CertificationRequest>> GetCertificationRequests(int start, int length, string keyword, int orderIndex, string orderDir, out int count)
        {
            var query = _context.CertificationRequests
                .Include(c => c.CertificationRequestState)
                .Where(c => string.IsNullOrWhiteSpace(keyword)
                || c.AppName.ToUpper().Contains(keyword.ToUpper())
                || c.CompanyName.ToUpper().Contains(keyword.ToUpper())
                || c.CertificationRequestState.Name.ToUpper().Contains(keyword.ToUpper()));

            count = query.Count();
            var isAsc = "asc".Equals(orderDir);
            switch (orderIndex)
            {
                case 0: query = isAsc ? query.OrderBy(q => q.AppName) : query.OrderByDescending(q => q.AppName); break;
                case 1: query = isAsc ? query.OrderBy(q => q.CompanyName) : query.OrderByDescending(q => q.CompanyName); break;
                case 2: query = isAsc ? query.OrderBy(q => q.UpdatedTime) : query.OrderByDescending(q => q.UpdatedTime); break;
                case 3: query = isAsc ? query.OrderBy(q => q.CertificationRequestState.DisplayOrder) : query.OrderByDescending(q => q.CertificationRequestState.DisplayOrder); break;
                default: query = query.OrderByDescending(q => q.UpdatedTime); break;
            }

            return Task.FromResult<IList<CertificationRequest>>(query.Skip(start).Take(length).ToList());
        }

        public Task<IList<CertificationRequest>> GetCertificationRequestsByUser(string microsoftAccount, int start, int length, string keyword, int orderIndex, string orderDir, out int count)
        {
            var query = _context.CertificationRequests
                .Include(c => c.CertificationRequestState)
                .Include(c => c.Owner)
                .Where(c => c.Owner.EmailAddress.Equals(microsoftAccount, StringComparison.OrdinalIgnoreCase)
                && (string.IsNullOrWhiteSpace(keyword)
                || c.AppName.ToUpper().Contains(keyword.ToUpper())
                || c.CompanyName.ToUpper().Contains(keyword.ToUpper())
                || c.CertificationRequestState.Name.ToUpper().Contains(keyword.ToUpper())));

            count = query.Count();
            var isAsc = "asc".Equals(orderDir);
            switch (orderIndex)
            {
                case 0: query = isAsc ? query.OrderBy(q => q.AppName) : query.OrderByDescending(q => q.AppName); break;
                case 1: query = isAsc ? query.OrderBy(q => q.CompanyName) : query.OrderByDescending(q => q.CompanyName); break;
                case 2: query = isAsc ? query.OrderBy(q => q.UpdatedTime) : query.OrderByDescending(q => q.UpdatedTime); break;
                case 3: query = isAsc ? query.OrderBy(q => q.CertificationRequestState.DisplayOrder) : query.OrderByDescending(q => q.CertificationRequestState.DisplayOrder); break;
                default: query = query.OrderByDescending(q => q.UpdatedTime); break;
            }

            return Task.FromResult<IList<CertificationRequest>>(query.Skip(start).Take(length).ToList());
        }

        public Task<CertificationRequest> GetCertificationRequestAndCommentsByIdAsync(Guid id)
        {
            return _context.CertificationRequests
               .Include(c => c.CertificationKind)
               .Include(c => c.AppDatabases).ThenInclude(a => a.Database)
               .Include(c => c.AppFrameworks).ThenInclude(a => a.Framework)
               .Include(c => c.Owner)
               .Include(c => c.Comments).ThenInclude(m => m.Author)
               .Include(c => c.Comments).ThenInclude(m => m.Replies).ThenInclude(r => r.Author)
               .AsNoTracking()
               .SingleOrDefaultAsync(c => c.Id.Equals(id));
        }

        public async Task AddCommentAsync(Guid id, string content, string microsoftAccount, string hostName)
        {
            var request = await _context.CertificationRequests.FirstOrDefaultAsync(c => c.Id.Equals(id));
            if (request != null)
            {
                var author = await _context.Users.FirstAsync(c => c.MicrosoftAccount.Equals(microsoftAccount, StringComparison.OrdinalIgnoreCase));
                var now = DateTime.Now;
                _context.Comments.Add(new Comment
                {
                    Id = Guid.NewGuid(),
                    CertificationRequest = request,
                    Content = content,
                    CreatedTime = now,
                    UpdatedTime = now,
                    Author = author
                });

                await _context.SaveChangesAsync();

                await _emailService.SendMessageForAddCommentAsync(id, request.AppName, author.Nickname, request.ContactEmail, content, now, hostName);
            }
        }

        public async Task DeleteCommentAsync(Guid commentId)
        {
            var comment = _context.Comments.Include(c => c.Replies).FirstOrDefault(c => c.Id.Equals(commentId));
            if (comment != null)
            {
                _context.Comments.Remove(comment);

                await _context.SaveChangesAsync();
            }
        }

        public Task<bool> HasAuthorShip(string microsoftAccount, Guid id)
        {
            return Task.FromResult(_context.Comments.Any(c => c.Id.Equals(id) && c.Author.MicrosoftAccount.Equals(microsoftAccount, StringComparison.OrdinalIgnoreCase)));
        }

        public async Task<Comment> ReplyCommentAsync(Guid id, string content, string microsoftAccount, string hostName)
        {
            var comment = _context.Comments.Include(c => c.Replies).Include(c => c.CertificationRequest).FirstOrDefault(c => c.Id.Equals(id));
            if (comment == null)
            {
                return null;
            }

            var now = DateTime.Now;
            comment.UpdatedTime = now;
            var author = await _context.Users.FirstAsync(c => c.MicrosoftAccount.Equals(microsoftAccount, StringComparison.OrdinalIgnoreCase));

            var reply = new Comment
            {
                Id = Guid.NewGuid(),
                Content = content,
                Author = author,
                CreatedTime = now,
                UpdatedTime = now
            };
            comment.Replies.Add(reply);

            await _context.SaveChangesAsync();

            await _emailService.SendMessageForReplyCommentAsync(comment.CertificationRequest.Id, comment.CertificationRequest.AppName, author.Nickname, comment.CertificationRequest.ContactEmail, reply.Content, now, hostName);

            return reply;
        }

        public Task<Comment> GetCommentByIdAsync(Guid id)
        {
            return Task.FromResult(_context.Comments.FirstOrDefault(c => c.Id.Equals(id)));
        }
    }
}